#!/usr/bin/env python3
"""
Generate Mermaid diagram training examples using Claude API.
Target: 300+ examples across all diagram types.
"""

import json
import os
import time
from pathlib import Path
from anthropic import Anthropic

# Config
OUTPUT_FILE = Path("data/patterns/mermaid_examples.jsonl")
TARGET_EXAMPLES = 300

client = Anthropic()

SYSTEM_PROMPT = """You are a software design analyst for Cyan, a design-first collaboration tool. You have deep expertise in:
- Design patterns (GoF, enterprise, microservices, Rust idioms)
- Software architecture (clean architecture, DDD, CQRS, event sourcing)
- UML and diagram generation using Mermaid syntax
- Project health analysis from integration data

When asked for diagrams, output valid Mermaid syntax in a code block. Be specific, actionable, and concise."""

# Categories with specific prompts
CATEGORIES = [
    # CLASS DIAGRAMS - Design Patterns
    {
        "category": "class_gof",
        "count": 30,
        "prompt": """Generate {n} training examples where user asks for a CLASS DIAGRAM of a GoF design pattern and assistant responds with valid Mermaid classDiagram.

Patterns to cover: Singleton, Factory Method, Abstract Factory, Builder, Prototype, Adapter, Bridge, Composite, Decorator, Facade, Flyweight, Proxy, Chain of Responsibility, Command, Iterator, Mediator, Memento, Observer, State, Strategy, Template Method, Visitor.

Each example should:
1. Have a natural user question (varied phrasing)
2. Include complete, valid Mermaid classDiagram syntax
3. Show relationships (inheritance, composition, dependency)
4. Include brief explanation of the pattern

Output as JSON array:
[{{"instruction": "user question", "output": "assistant response with mermaid code block"}}]"""
    },
    {
        "category": "class_enterprise",
        "count": 25,
        "prompt": """Generate {n} training examples for CLASS DIAGRAMS of enterprise/DDD patterns.

Patterns: Repository, Unit of Work, Service Layer, Domain Model, Data Mapper, Active Record, Table Module, Aggregate, Entity, Value Object, Domain Event, Specification, CQRS read/write models.

Each should have Mermaid classDiagram with proper relationships.

Output as JSON array:
[{{"instruction": "user question", "output": "assistant response with mermaid"}}]"""
    },
    {
        "category": "class_rust",
        "count": 20,
        "prompt": """Generate {n} training examples for CLASS DIAGRAMS showing Rust-idiomatic patterns.

Topics: Trait objects, Newtype pattern, Builder with typestate, Error handling with Result, Actor model, Channel-based observer, Smart pointers (Box, Rc, Arc), Interior mutability (RefCell, Mutex).

Show traits as <<interface>>, impl as inheritance. Include Rust code snippets.

Output as JSON array:
[{{"instruction": "user question", "output": "assistant response with mermaid + rust code"}}]"""
    },

    # SEQUENCE DIAGRAMS
    {
        "category": "sequence_auth",
        "count": 20,
        "prompt": """Generate {n} training examples for SEQUENCE DIAGRAMS of authentication/authorization flows.

Flows: OAuth2, OIDC, JWT refresh, API key auth, mTLS, SSO, MFA, passwordless, session management, token revocation.

Use proper sequenceDiagram syntax with participants, messages, alt/opt blocks, notes.

Output as JSON array:
[{{"instruction": "user question", "output": "assistant response with mermaid sequenceDiagram"}}]"""
    },
    {
        "category": "sequence_distributed",
        "count": 25,
        "prompt": """Generate {n} training examples for SEQUENCE DIAGRAMS of distributed systems.

Flows: Saga pattern, 2PC, event sourcing, CQRS command flow, message queue processing, circuit breaker, retry with backoff, distributed cache, consensus (simplified), P2P gossip sync.

Show failure paths with alt blocks.

Output as JSON array:
[{{"instruction": "user question", "output": "assistant response with mermaid sequenceDiagram"}}]"""
    },
    {
        "category": "sequence_api",
        "count": 20,
        "prompt": """Generate {n} training examples for SEQUENCE DIAGRAMS of API interactions.

Flows: REST CRUD, GraphQL query/mutation, WebSocket lifecycle, gRPC streaming, webhook delivery, file upload, pagination, rate limiting, caching with ETags.

Output as JSON array:
[{{"instruction": "user question", "output": "assistant response with mermaid sequenceDiagram"}}]"""
    },

    # FLOWCHARTS
    {
        "category": "flowchart_decisions",
        "count": 25,
        "prompt": """Generate {n} training examples for FLOWCHARTS showing decision processes.

Topics: Error handling strategy, retry logic, feature flag evaluation, A/B test routing, cache hit/miss, request validation pipeline, authorization checks, deployment approval, incident response.

Use flowchart TD/LR with decision diamonds, styling for success/error states.

Output as JSON array:
[{{"instruction": "user question", "output": "assistant response with mermaid flowchart"}}]"""
    },
    {
        "category": "flowchart_devops",
        "count": 20,
        "prompt": """Generate {n} training examples for FLOWCHARTS of DevOps/CI/CD processes.

Topics: CI pipeline, CD pipeline, blue-green deployment, canary release, rollback decision, PR review flow, security scanning, infrastructure provisioning, monitoring alerting.

Output as JSON array:
[{{"instruction": "user question", "output": "assistant response with mermaid flowchart"}}]"""
    },

    # STATE DIAGRAMS
    {
        "category": "state_lifecycle",
        "count": 25,
        "prompt": """Generate {n} training examples for STATE DIAGRAMS of entity lifecycles.

Entities: Order, Payment, User account, Subscription, Document, Task/Issue, Connection (WebSocket/TCP), Session, Job/Worker, Deployment.

Use stateDiagram-v2 with nested states where appropriate, transitions with events.

Output as JSON array:
[{{"instruction": "user question", "output": "assistant response with mermaid stateDiagram-v2"}}]"""
    },
    {
        "category": "state_rust",
        "count": 15,
        "prompt": """Generate {n} training examples for STATE DIAGRAMS with Rust enum implementations.

Show both the Mermaid state diagram AND the corresponding Rust enum with match-based transitions.

Topics: Connection state, Parser state, Game state, Form validation, Protocol state machine.

Output as JSON array:
[{{"instruction": "user question", "output": "assistant response with mermaid + rust enum code"}}]"""
    },

    # ER DIAGRAMS
    {
        "category": "er_domains",
        "count": 25,
        "prompt": """Generate {n} training examples for ER DIAGRAMS of various domains.

Domains: E-commerce (orders, products, users), Blog/CMS, Task management, Chat/messaging, Calendar/booking, Inventory, HR/employees, Social network, Event sourcing tables, Multi-tenant SaaS.

Use erDiagram with proper relationships (||--|{, etc.), column types, PK/FK.

Output as JSON array:
[{{"instruction": "user question", "output": "assistant response with mermaid erDiagram"}}]"""
    },

    # ARCHITECTURE/COMPONENT
    {
        "category": "architecture",
        "count": 30,
        "prompt": """Generate {n} training examples for ARCHITECTURE/COMPONENT DIAGRAMS using flowchart with subgraphs.

Topics: Microservices layout, Clean architecture layers, Hexagonal architecture, P2P network topology, Event-driven architecture, API gateway pattern, BFF pattern, Sidecar pattern, Service mesh, Data pipeline.

Use flowchart with subgraphs for logical grouping, styled nodes.

Output as JSON array:
[{{"instruction": "user question", "output": "assistant response with mermaid flowchart subgraphs"}}]"""
    },

    # MIXED - Project health + diagrams
    {
        "category": "health_with_diagram",
        "count": 20,
        "prompt": """Generate {n} training examples where user provides project health context AND asks for a diagram.

Format:
<context>
Ticket info, Slack mentions, PRs, etc.
</context>
Question asking for analysis AND a diagram

Response should:
1. Analyze the health issue (use emoji 🔴/🟡/🟢 with evidence)
2. Provide a relevant Mermaid diagram (sequence, flowchart, or class)
3. Explain how the diagram addresses the issue

Output as JSON array:
[{{"instruction": "user question with context", "output": "analysis + mermaid diagram"}}]"""
    },
]


def generate_examples(category: dict) -> list:
    """Generate examples for a category using Claude."""
    prompt = f"""Generate exactly {category["count"]} training examples as a JSON array.

{category["prompt"].format(n=category["count"])}

IMPORTANT: Output ONLY a valid JSON array, no other text. Start with [ and end with ].
Each object must have "instruction" and "output" keys."""

    try:
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=16000,
            messages=[{
                "role": "user",
                "content": prompt
            }]
        )

        text = response.content[0].text.strip()

        # Try to find JSON array
        start = text.find('[')
        end = text.rfind(']') + 1

        if start >= 0 and end > start:
            json_str = text[start:end]
            try:
                examples = json.loads(json_str)
                return examples
            except json.JSONDecodeError as e:
                # Try to fix common issues
                print(f"  JSON parse error: {e}")
                # Sometimes Claude adds trailing commas
                json_str = json_str.replace(",]", "]").replace(",\n]", "\n]")
                try:
                    examples = json.loads(json_str)
                    return examples
                except:
                    print(f"  Could not fix JSON, saving raw for debug")
                    with open(f"debug_{category['category']}.txt", "w") as f:
                        f.write(text)
                    return []
        else:
            print(f"  Warning: No JSON array found in response")
            print(f"  Response preview: {text[:200]}...")
            return []

    except Exception as e:
        print(f"  Error: {e}")
        return []


def convert_to_messages(example: dict) -> dict:
    """Convert to MLX messages format."""
    return {
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": example["instruction"]},
            {"role": "assistant", "content": example["output"]}
        ]
    }


def main():
    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)

    all_examples = []

    print(f"Generating Mermaid training examples...")
    print(f"Target: ~{sum(c['count'] for c in CATEGORIES)} examples\n")

    for i, category in enumerate(CATEGORIES):
        print(f"[{i+1}/{len(CATEGORIES)}] {category['category']} (target: {category['count']})")

        examples = generate_examples(category)
        print(f"    Generated: {len(examples)}")

        all_examples.extend(examples)

        # Rate limiting - wait 60 seconds to reset token budget
        print(f"    Waiting 60s for rate limit...")
        time.sleep(60)

    print(f"\nTotal generated: {len(all_examples)}")

    # Convert to messages format
    formatted = [convert_to_messages(ex) for ex in all_examples if ex.get("instruction") and ex.get("output")]
    print(f"Valid examples: {len(formatted)}")

    # Save
    with open(OUTPUT_FILE, "w") as f:
        for ex in formatted:
            f.write(json.dumps(ex) + "\n")

    print(f"Saved to {OUTPUT_FILE}")

    # Stats
    print("\nDiagram types in output:")
    content = str(formatted)
    for dtype in ["classDiagram", "sequenceDiagram", "flowchart", "stateDiagram", "erDiagram"]:
        count = content.count(dtype)
        print(f"  {dtype}: {count}")


if __name__ == "__main__":
    main()