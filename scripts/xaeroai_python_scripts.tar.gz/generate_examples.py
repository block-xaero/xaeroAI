#!/usr/bin/env python3
"""
Generate training examples from scraped patterns.
Uses Claude API to create diverse Q&A pairs.

Input: data/patterns/raw_patterns.json
Output: data/patterns/generated_examples.jsonl
"""

import json
import os
from pathlib import Path
from typing import Iterator
import time

try:
    import anthropic
    HAS_ANTHROPIC = True
except ImportError:
    HAS_ANTHROPIC = False
    print("Warning: anthropic not installed. Install with: pip install anthropic")

SYSTEM_PROMPT = """You are a software architect for Cyan, a design-first collaboration tool. 
Analyze code structure, identify patterns and anti-patterns, and suggest improvements.
Be specific, actionable, and reference established patterns (GoF, Fowler, DDD) when relevant.
Focus on architecture-level concerns: coupling, cohesion, data flow, scalability."""


def load_patterns(input_file: str = "data/patterns/raw_patterns.json") -> list[dict]:
    with open(input_file) as f:
        return json.load(f)


def generate_examples_for_pattern(client, pattern: dict) -> list[dict]:
    """Generate 3-4 training examples per pattern"""
    examples = []

    # Type 1: Pattern Identification
    ex1 = generate_identification_example(client, pattern)
    if ex1:
        examples.append(ex1)

    # Type 2: Problem → Pattern Recommendation
    ex2 = generate_recommendation_example(client, pattern)
    if ex2:
        examples.append(ex2)

    # Type 3: Code Review (if code example exists)
    if pattern.get("code_example"):
        ex3 = generate_review_example(client, pattern)
        if ex3:
            examples.append(ex3)

    # Type 4: Anti-pattern Detection
    ex4 = generate_antipattern_example(client, pattern)
    if ex4:
        examples.append(ex4)

    return examples


def generate_identification_example(client, pattern: dict) -> dict | None:
    """Generate example: given code, identify the pattern"""

    code_example = pattern.get('code_example') or 'N/A'

    prompt = f"""Generate a training example for pattern identification.

Pattern: {pattern['name']}
Category: {pattern['category']}
Language: {pattern.get('language', 'general')}
Problem it solves: {pattern['problem'][:300]}
Solution approach: {pattern['solution'][:300]}
Example code snippet: {code_example[:400]}

Create a training example where:
- User shows code implementing this pattern
- Assistant identifies the pattern and explains why

CRITICAL: Return ONLY valid JSON. All newlines in content must be escaped as \\n. No actual line breaks inside string values.

{{"messages": [
  {{"role": "system", "content": "You are a software architect. Analyze code structure and identify patterns."}},
  {{"role": "user", "content": "<code>\\n[code here]\\n</code>\\n\\nWhat design pattern is used here?"}},
  {{"role": "assistant", "content": "**Pattern: {pattern['name']}**\\n\\n[2-3 sentences explaining the pattern and why it fits]"}}
]}}"""

    return call_claude(client, prompt)


def generate_recommendation_example(client, pattern: dict) -> dict | None:
    """Generate example: given problem, recommend pattern"""

    prompt = f"""Generate a training example for pattern recommendation.

Pattern: {pattern['name']}
Problem it solves: {pattern['problem'][:300]}
Solution: {pattern['solution'][:300]}

Create a training example where user describes a problem and assistant recommends this pattern.

CRITICAL: Return ONLY valid JSON. All newlines in content must be escaped as \\n. No actual line breaks inside string values.

{{"messages": [
  {{"role": "system", "content": "You are a software architect. Recommend design patterns for problems."}},
  {{"role": "user", "content": "[1-2 sentence problem description]"}},
  {{"role": "assistant", "content": "**Recommended: {pattern['name']}**\\n\\n[2-3 sentences on why and how to implement]"}}
]}}"""

    return call_claude(client, prompt)


def generate_review_example(client, pattern: dict) -> dict | None:
    """Generate example: review code that uses pattern correctly or incorrectly"""

    code_example = pattern.get('code_example') or 'N/A'

    prompt = f"""Generate a code review training example.

Pattern: {pattern['name']}
Solution: {pattern['solution'][:300]}
Code snippet: {code_example[:400]}

Create example where user shows code with minor issues, assistant reviews it.

CRITICAL: Return ONLY valid JSON. All newlines in content must be escaped as \\n. No actual line breaks inside string values.

{{"messages": [
  {{"role": "system", "content": "You are a software architect. Review code for design issues."}},
  {{"role": "user", "content": "<code>\\n[code with minor issue]\\n</code>\\n\\nReview this implementation."}},
  {{"role": "assistant", "content": "**Code Review: {pattern['name']}**\\n\\n✅ Good: [what works]\\n\\n⚠️ Improve: [specific fix]"}}
]}}"""

    return call_claude(client, prompt)


def generate_antipattern_example(client, pattern: dict) -> dict | None:
    """Generate example: identify when pattern is misused or missing"""

    prompt = f"""Generate an anti-pattern detection training example.

Pattern: {pattern['name']}
Problem it solves: {pattern['problem'][:300]}

Create example where user shows code that SHOULD use this pattern but doesn't.

CRITICAL: Return ONLY valid JSON. All newlines in content must be escaped as \\n. No actual line breaks inside string values.

{{"messages": [
  {{"role": "system", "content": "You are a software architect. Identify design issues and suggest patterns."}},
  {{"role": "user", "content": "<code>\\n[code with design smell]\\n</code>\\n\\nAny design issues here?"}},
  {{"role": "assistant", "content": "🔴 **Issue Detected**\\n\\n[1 sentence problem]\\n\\n**Fix: Use {pattern['name']}**\\n\\n[2 sentences on how to refactor]"}}
]}}"""

    return call_claude(client, prompt)


def call_claude(client, prompt: str) -> dict | None:
    """Call Claude API and parse JSON response"""
    if not HAS_ANTHROPIC or not client:
        return None

    try:
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=2000,
            messages=[{"role": "user", "content": prompt}]
        )

        text = response.content[0].text.strip()

        # Clean up response - find JSON
        if "```json" in text:
            text = text.split("```json")[1].split("```")[0].strip()
        elif "```" in text:
            parts = text.split("```")
            if len(parts) >= 2:
                text = parts[1].strip()
                # Remove language identifier if present
                if text.startswith("json"):
                    text = text[4:].strip()

        # Try to find JSON object boundaries
        start = text.find("{")
        end = text.rfind("}") + 1
        if start != -1 and end > start:
            text = text[start:end]

        # Fix common JSON issues
        # Replace literal newlines in strings with \n
        import re

        # Parse and validate
        example = json.loads(text)

        # Validate structure
        if "messages" not in example:
            return None
        if len(example["messages"]) != 3:
            return None

        return example

    except json.JSONDecodeError as e:
        print(f"    JSON parse error: {e}")
        return None
    except Exception as e:
        print(f"    Error calling Claude: {e}")
        return None


def generate_without_api(pattern: dict) -> list[dict]:
    """Generate basic examples without API (template-based)"""
    examples = []

    # Template 1: Pattern explanation
    examples.append({
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"Explain the {pattern['name']} pattern and when to use it."},
            {"role": "assistant", "content": f"""**{pattern['name']}**

**Category:** {pattern['category'].title()} / {pattern['subcategory'].title()}

**Problem:**
{pattern['problem']}

**Solution:**
{pattern['solution']}

**When to use:**
{chr(10).join('- ' + u for u in pattern.get('when_to_use', ['When the described problem occurs']))}

**Language:** {pattern.get('language', 'general').title()}"""}
        ]
    })

    # Template 2: Code example if available
    if pattern.get("code_example"):
        examples.append({
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"Show me an example of the {pattern['name']} pattern."},
                {"role": "assistant", "content": f"""**{pattern['name']} Example**

{pattern['solution'][:300]}

```{pattern.get('language', '')}
{pattern['code_example']}
```

This pattern is useful because it {pattern['problem'][:200].lower()}"""}
            ]
        })

    return examples


def main():
    output_dir = Path("data/patterns")
    output_dir.mkdir(parents=True, exist_ok=True)

    # Load scraped patterns
    input_file = output_dir / "raw_patterns.json"
    if not input_file.exists():
        print(f"Error: {input_file} not found. Run scrape_patterns.py first.")
        return

    patterns = load_patterns(input_file)
    print(f"Loaded {len(patterns)} patterns")

    # Initialize Claude client if available
    client = None
    if HAS_ANTHROPIC and os.environ.get("ANTHROPIC_API_KEY"):
        client = anthropic.Anthropic()
        print("Using Claude API for example generation")
    else:
        print("No API key found. Using template-based generation.")
        print("Set ANTHROPIC_API_KEY for better examples.")

    # Generate examples
    all_examples = []

    for i, pattern in enumerate(patterns):
        print(f"[{i+1}/{len(patterns)}] Generating examples for: {pattern['name']}")

        if client:
            examples = generate_examples_for_pattern(client, pattern)
            time.sleep(0.5)  # Rate limiting
        else:
            examples = generate_without_api(pattern)

        all_examples.extend(examples)
        print(f"    Generated {len(examples)} examples")

    # Save to JSONL
    output_file = output_dir / "generated_examples.jsonl"
    with open(output_file, "w") as f:
        for ex in all_examples:
            f.write(json.dumps(ex) + "\n")

    print(f"\nDone! Generated {len(all_examples)} examples")
    print(f"Saved to {output_file}")


if __name__ == "__main__":
    main()