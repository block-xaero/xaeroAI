#!/usr/bin/env python3
"""
Combine original training data with new pattern examples.
Shuffle to prevent catastrophic forgetting.

Input:
  - data/design_analyst/train.jsonl (original ~500 examples, messages format)
  - data/patterns/generated_examples.jsonl (new pattern examples, instruction/output format)

Output:
  - data/combined_train.jsonl (shuffled combination, all in messages format)
  - data/mlx_combined/train.jsonl + valid.jsonl (90/10 split for MLX)
"""

import json
import random
from pathlib import Path

# System prompt for pattern examples
PATTERN_SYSTEM_PROMPT = """You are a software design analyst for Cyan, a design-first collaboration tool. You have deep expertise in:
- Design patterns (GoF, enterprise, microservices, Rust idioms)
- Software architecture (clean architecture, DDD, CQRS, event sourcing)
- Project health analysis from integration data
- Code quality and best practices

Be specific, actionable, and concise."""


def load_jsonl(path: Path) -> list[dict]:
    """Load JSONL file"""
    examples = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                examples.append(json.loads(line))
    return examples


def convert_pattern_to_messages(example: dict) -> dict:
    """Convert instruction/output format to messages format."""
    # Already in messages format
    if "messages" in example:
        return example

    # Convert from instruction/output format
    instruction = example.get("instruction", "")
    input_text = example.get("input", "")
    output = example.get("output", "")

    # Combine instruction and input if both present
    user_content = instruction
    if input_text:
        user_content = f"{instruction}\n\n{input_text}"

    return {
        "messages": [
            {"role": "system", "content": PATTERN_SYSTEM_PROMPT},
            {"role": "user", "content": user_content},
            {"role": "assistant", "content": output}
        ]
    }


def validate_example(example: dict) -> bool:
    """Validate training example structure"""
    if "messages" not in example:
        return False

    msgs = example["messages"]
    if len(msgs) < 2:  # At minimum need user + assistant
        return False

    # Find user and assistant messages
    has_user = any(m.get("role") == "user" for m in msgs)
    has_assistant = any(m.get("role") == "assistant" for m in msgs)

    if not has_user or not has_assistant:
        return False

    # Check content length
    user_msg = next((m for m in msgs if m.get("role") == "user"), None)
    asst_msg = next((m for m in msgs if m.get("role") == "assistant"), None)

    if not user_msg or len(user_msg.get("content", "")) < 10:
        return False
    if not asst_msg or len(asst_msg.get("content", "")) < 20:
        return False

    return True


def main():
    data_dir = Path("data")

    # Load original examples (already in messages format)
    original_file = data_dir / "design_analyst" / "train.jsonl"
    if original_file.exists():
        original = load_jsonl(original_file)
        print(f"Loaded {len(original)} original examples")
    else:
        print(f"Warning: {original_file} not found")
        original = []

    # Load new pattern examples (instruction/output format)
    patterns_file = data_dir / "patterns" / "generated_examples.jsonl"
    if patterns_file.exists():
        raw_patterns = load_jsonl(patterns_file)
        print(f"Loaded {len(raw_patterns)} pattern examples")

        # Convert to messages format
        patterns = [convert_pattern_to_messages(ex) for ex in raw_patterns]
        print(f"Converted {len(patterns)} patterns to messages format")
    else:
        print(f"Warning: {patterns_file} not found")
        patterns = []

    # Combine
    combined = original + patterns
    print(f"Combined: {len(combined)} total examples")

    # Validate
    valid = [ex for ex in combined if validate_example(ex)]
    invalid_count = len(combined) - len(valid)
    if invalid_count > 0:
        print(f"Filtered out {invalid_count} invalid examples")

    # Shuffle
    random.seed(42)  # Reproducible
    random.shuffle(valid)
    print(f"Shuffled {len(valid)} valid examples")

    # Save combined
    output_file = data_dir / "combined_train.jsonl"
    with open(output_file, "w") as f:
        for ex in valid:
            f.write(json.dumps(ex) + "\n")

    print(f"Saved to {output_file}")

    # Also create train/valid split for MLX
    split_idx = int(len(valid) * 0.9)
    train_examples = valid[:split_idx]
    valid_examples = valid[split_idx:]

    mlx_dir = data_dir / "mlx_combined"
    mlx_dir.mkdir(exist_ok=True)

    with open(mlx_dir / "train.jsonl", "w") as f:
        for ex in train_examples:
            f.write(json.dumps(ex) + "\n")

    with open(mlx_dir / "valid.jsonl", "w") as f:
        for ex in valid_examples:
            f.write(json.dumps(ex) + "\n")

    print(f"\nMLX format saved to {mlx_dir}/")
    print(f"  train.jsonl: {len(train_examples)} examples")
    print(f"  valid.jsonl: {len(valid_examples)} examples")

    # Stats
    print("\n=== Dataset Stats ===")
    print(f"Original examples: {len(original)}")
    print(f"Pattern examples: {len(patterns)}")
    print(f"Total valid: {len(valid)}")

    # Category breakdown
    categories = {}
    for ex in valid:
        content = str(ex).lower()
        if "design drift" in content or "over-architect" in content or "stale" in content:
            cat = "project_health"
        elif "factory" in content or "singleton" in content or "observer" in content:
            cat = "gof_patterns"
        elif "repository" in content or "unit of work" in content or "domain model" in content:
            cat = "enterprise_patterns"
        elif "microservice" in content or "saga" in content or "cqrs" in content:
            cat = "microservices"
        elif "rust" in content or "trait" in content or "ownership" in content:
            cat = "rust_idioms"
        else:
            cat = "other"

        categories[cat] = categories.get(cat, 0) + 1

    print("\nBy category:")
    for cat, count in sorted(categories.items(), key=lambda x: -x[1]):
        print(f"  {cat}: {count}")

    # Print training command
    print("\n" + "=" * 60)
    print("To train with MLX:")
    print("=" * 60)
    print(f"""
python -m mlx_lm.lora \\
    --model microsoft/Phi-3-mini-4k-instruct \\
    --train \\
    --data {mlx_dir} \\
    --batch-size 2 \\
    --iters 1500 \\
    --learning-rate 1e-5 \\
    --lora-layers 16 \\
    --adapter-path adapters/design-analyst-v2
""")


if __name__ == "__main__":
    main()