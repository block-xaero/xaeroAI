#!/usr/bin/env python3
"""
Combine all training data (original + patterns + mermaid) and continue training.
Resumes from existing checkpoint.
"""

import json
import random
from pathlib import Path
import subprocess
import sys

# Paths
DATA_DIR = Path("data")
EXISTING_COMBINED = DATA_DIR / "mlx_combined" / "train.jsonl"
MERMAID_FILE = DATA_DIR / "patterns" / "mermaid_examples.jsonl"
OUTPUT_DIR = DATA_DIR / "mlx_final"

# Training config - resume from checkpoint
MODEL_NAME = "microsoft/Phi-3-mini-4k-instruct"
ADAPTER_PATH = "adapters/design-analyst-v2"
NEW_ADAPTER_PATH = "adapters/design-analyst-v3"  # New version with mermaid


def load_jsonl(path: Path) -> list:
    """Load JSONL file."""
    examples = []
    if path.exists():
        with open(path) as f:
            for line in f:
                if line.strip():
                    examples.append(json.loads(line))
    return examples


def validate_example(ex: dict) -> bool:
    """Basic validation."""
    if "messages" not in ex:
        return False
    msgs = ex["messages"]
    if len(msgs) < 2:
        return False
    # Check for user and assistant
    has_user = any(m.get("role") == "user" for m in msgs)
    has_asst = any(m.get("role") == "assistant" for m in msgs)
    return has_user and has_asst


def main():
    print("=" * 60)
    print("Combine All Training Data")
    print("=" * 60 + "\n")

    # Load existing training data (original 500 + patterns 361)
    existing = load_jsonl(EXISTING_COMBINED)
    print(f"Existing combined data: {len(existing)} examples")

    # Also load validation set
    existing_valid = load_jsonl(DATA_DIR / "mlx_combined" / "valid.jsonl")
    print(f"Existing validation: {len(existing_valid)} examples")

    # Load new mermaid examples
    mermaid = load_jsonl(MERMAID_FILE)
    print(f"New Mermaid examples: {len(mermaid)} examples")

    if not mermaid:
        print("\n⚠️  No Mermaid examples found!")
        print(f"Run: python scripts/generate_mermaid_examples.py first")
        sys.exit(1)

    # Combine all
    all_train = existing + mermaid
    print(f"\nTotal before validation: {len(all_train)}")

    # Validate
    valid_examples = [ex for ex in all_train if validate_example(ex)]
    invalid_count = len(all_train) - len(valid_examples)
    if invalid_count > 0:
        print(f"Filtered {invalid_count} invalid examples")

    # Shuffle
    random.seed(42)
    random.shuffle(valid_examples)

    # Split - keep 10% for validation (including mermaid examples)
    mermaid_for_valid = mermaid[::10]  # Every 10th mermaid example
    new_valid = existing_valid + mermaid_for_valid

    # Remove validation examples from training
    valid_ids = {json.dumps(ex) for ex in new_valid}
    train_examples = [ex for ex in valid_examples if json.dumps(ex) not in valid_ids]

    print(f"\nFinal split:")
    print(f"  Training: {len(train_examples)}")
    print(f"  Validation: {len(new_valid)}")

    # Save
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    with open(OUTPUT_DIR / "train.jsonl", "w") as f:
        for ex in train_examples:
            f.write(json.dumps(ex) + "\n")

    with open(OUTPUT_DIR / "valid.jsonl", "w") as f:
        for ex in new_valid:
            f.write(json.dumps(ex) + "\n")

    print(f"\nSaved to {OUTPUT_DIR}/")

    # Stats
    print("\n" + "=" * 60)
    print("Dataset Statistics")
    print("=" * 60)

    content = str(train_examples)
    categories = {
        "Project health": content.lower().count("design drift") + content.lower().count("over-architect"),
        "Mermaid diagrams": content.count("```mermaid"),
        "Rust code": content.count("```rust"),
        "classDiagram": content.count("classDiagram"),
        "sequenceDiagram": content.count("sequenceDiagram"),
        "flowchart": content.count("flowchart"),
        "stateDiagram": content.count("stateDiagram"),
        "erDiagram": content.count("erDiagram"),
    }

    for cat, count in categories.items():
        print(f"  {cat}: {count}")

    # Training command
    print("\n" + "=" * 60)
    print("Continue Training (from checkpoint)")
    print("=" * 60)

    # Calculate iterations - want ~2-3 epochs over new data
    new_examples = len(mermaid)
    additional_iters = (new_examples * 3) // 2  # ~3 epochs at batch 2

    print(f"""
Option 1: Continue from v2 checkpoint (recommended):

python -m mlx_lm lora \\
    --model {MODEL_NAME} \\
    --train \\
    --data {OUTPUT_DIR} \\
    --batch-size 2 \\
    --iters {additional_iters} \\
    --learning-rate 5e-6 \\
    --num-layers 16 \\
    --resume-adapter-file {ADAPTER_PATH}/adapters.safetensors \\
    --adapter-path {NEW_ADAPTER_PATH}

Option 2: Train fresh on all data:

python -m mlx_lm lora \\
    --model {MODEL_NAME} \\
    --train \\
    --data {OUTPUT_DIR} \\
    --batch-size 2 \\
    --iters 2000 \\
    --learning-rate 1e-5 \\
    --num-layers 16 \\
    --adapter-path {NEW_ADAPTER_PATH}
""")

    response = input("\nStart training? [continue/fresh/no]: ").strip().lower()

    if response == "continue":
        cmd = [
            sys.executable, "-m", "mlx_lm", "lora",
            "--model", MODEL_NAME,
            "--train",
            "--data", str(OUTPUT_DIR),
            "--batch-size", "2",
            "--iters", str(additional_iters),
            "--learning-rate", "5e-6",
            "--num-layers", "16",
            "--resume-adapter-file", f"{ADAPTER_PATH}/adapters.safetensors",
            "--adapter-path", NEW_ADAPTER_PATH,
        ]
        print(f"\nRunning: {' '.join(cmd)}\n")
        subprocess.run(cmd)

    elif response == "fresh":
        cmd = [
            sys.executable, "-m", "mlx_lm", "lora",
            "--model", MODEL_NAME,
            "--train",
            "--data", str(OUTPUT_DIR),
            "--batch-size", "2",
            "--iters", "2000",
            "--learning-rate", "1e-5",
            "--num-layers", "16",
            "--adapter-path", NEW_ADAPTER_PATH,
        ]
        print(f"\nRunning: {' '.join(cmd)}\n")
        subprocess.run(cmd)
    else:
        print("\nSkipped. Run the command manually when ready.")


if __name__ == "__main__":
    main()