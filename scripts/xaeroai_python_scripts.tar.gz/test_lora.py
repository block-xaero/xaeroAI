"""
Test the trained LoRA model - simple version.
"""
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel

# =============================================================================
# Config
# =============================================================================

BASE_MODEL_ID = "microsoft/Phi-3-mini-4k-instruct"
LORA_PATH = "/Users/anirudhvyas/xaeroai/checkpoints/design-analyst-lora"

# =============================================================================
# Load
# =============================================================================

print("Loading tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL_ID)

print("Loading base model...")
base_model = AutoModelForCausalLM.from_pretrained(
    BASE_MODEL_ID,
    torch_dtype=torch.float16,
    device_map="auto",
    trust_remote_code=True,
)

print(f"Loading LoRA from {LORA_PATH}...")
model = PeftModel.from_pretrained(base_model, LORA_PATH, local_files_only=True)

# Verify LoRA
lora_params = [n for n, p in model.named_parameters() if "lora" in n.lower()]
print(f"\n✅ LoRA parameters loaded: {len(lora_params)}")

# =============================================================================
# Test with LoRA (merged model)
# =============================================================================

print("\n" + "="*60)
print("TESTING LORA MODEL")
print("="*60)

test_prompt = """<context>
Ticket: PROJ-123 "Auth Service Redesign"
First mentioned: 45 days ago
Slack mentions: 47 (across 8 threads)
PRs linked: 0
Design board: "Auth Flow v2" last edited 38 days ago
Contributors discussing: 6 people
</context>

Analyze this ticket's health."""

messages = [
    {"role": "system", "content": "You are a software design analyst for Cyan. Analyze project health. Identify design drift, over-architecture, stale designs. Be specific and actionable."},
    {"role": "user", "content": test_prompt}
]

inputs = tokenizer.apply_chat_template(messages, return_tensors="pt", return_dict=True).to(model.device)

print("Generating...")
outputs = model.generate(
    **inputs,
    max_new_tokens=300,
    do_sample=False,
    use_cache=False,
    pad_token_id=tokenizer.eos_token_id
)

response = tokenizer.decode(outputs[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)
print("\nResponse:")
print(response)

# =============================================================================
# Now test BASE model (without LoRA) for comparison
# =============================================================================

print("\n" + "="*60)
print("TESTING BASE MODEL (no LoRA)")
print("="*60)

print("Loading fresh base model...")
base_only = AutoModelForCausalLM.from_pretrained(
    BASE_MODEL_ID,
    torch_dtype=torch.float16,
    device_map="auto",
    trust_remote_code=True,
)

inputs = tokenizer.apply_chat_template(messages, return_tensors="pt", return_dict=True).to(base_only.device)

print("Generating...")
outputs = base_only.generate(
    **inputs,
    max_new_tokens=300,
    do_sample=False,
    use_cache=False,
    pad_token_id=tokenizer.eos_token_id
)

base_response = tokenizer.decode(outputs[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)
print("\nResponse:")
print(base_response)

# =============================================================================
# Compare
# =============================================================================

print("\n" + "="*60)
if response == base_response:
    print("⚠️  SAME OUTPUT - LoRA training didn't change behavior")
    print("   Need more training epochs or more data")
else:
    print("✅ DIFFERENT OUTPUT - LoRA is working!")
print("="*60)