#!/usr/bin/env python3
"""
Test design-analyst model with various prompts.

Usage:
    python scripts/test_design_analyst.py
    python scripts/test_design_analyst.py --model models/design-analyst-v4-q4.gguf
    python scripts/test_design_analyst.py --use-ollama
"""

import argparse
import subprocess
import sys

# Test prompts covering all capabilities
TEST_PROMPTS = [
    # 1. Project health / ticket analysis (original use case)
    {
        "name": "Ticket Health Analysis",
        "prompt": "<context>Ticket: AUTH-101, Days open: 45, Slack mentions: 67, PRs: 0, Assigned: unassigned</context> Analyze this ticket health and provide recommendations.",
        "expected": "JSON with analysis"
    },

    # 2. Another ticket scenario
    {
        "name": "Stale PR Analysis",
        "prompt": "<context>Ticket: PERF-203, Days open: 12, Slack mentions: 3, PRs: 2 (both stale for 8 days), Assigned: john.doe</context> What's the status of this ticket?",
        "expected": "Analysis mentioning stale PRs"
    },

    # 3. Mermaid sequence diagram
    {
        "name": "Sequence Diagram",
        "prompt": "Create a Mermaid sequenceDiagram for user authentication with JWT tokens",
        "expected": "Valid sequenceDiagram syntax"
    },

    # 4. Mermaid flowchart
    {
        "name": "Flowchart",
        "prompt": "Create a Mermaid flowchart for error handling with retry logic",
        "expected": "Valid flowchart syntax"
    },

    # 5. Mermaid class diagram
    {
        "name": "Class Diagram",
        "prompt": "Create a Mermaid classDiagram for the Strategy design pattern",
        "expected": "Valid classDiagram syntax"
    },

    # 6. Design pattern explanation
    {
        "name": "Design Pattern",
        "prompt": "Explain the Observer pattern and when to use it in a distributed system",
        "expected": "Pattern explanation"
    },
]


def test_with_llama_cpp(model_path: str, prompt: str, max_tokens: int = 400):
    """Test using llama-cli"""
    # Format prompt for Phi-3
    formatted = f"<|user|>\n{prompt}<|end|>\n<|assistant|>\n"

    # Find llama-cli
    llama_cli = None
    for path in ["llama-cli", "~/llama.cpp/build/bin/llama-cli", "/opt/homebrew/bin/llama-cli"]:
        try:
            result = subprocess.run(["which", path.replace("~", str(__import__('pathlib').Path.home()))],
                                    capture_output=True, text=True)
            if result.returncode == 0:
                llama_cli = result.stdout.strip()
                break
        except:
            pass

    if not llama_cli:
        # Try direct
        llama_cli = "llama-cli"

    cmd = [
        llama_cli,
        "-m", model_path,
        "-p", formatted,
        "-n", str(max_tokens),
        "--temp", "0.7",
        "-ngl", "99",  # GPU layers
    ]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        return result.stdout
    except subprocess.TimeoutExpired:
        return "TIMEOUT"
    except FileNotFoundError:
        return f"ERROR: llama-cli not found. Install llama.cpp or use --use-ollama"


def test_with_ollama(model_name: str, prompt: str):
    """Test using Ollama"""
    cmd = ["ollama", "run", model_name, prompt]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        return result.stdout
    except subprocess.TimeoutExpired:
        return "TIMEOUT"
    except FileNotFoundError:
        return "ERROR: ollama not found"


def test_with_mlx(adapter_path: str, prompt: str, max_tokens: int = 400):
    """Test using mlx_lm (if GGUF not ready yet)"""
    cmd = [
        "python", "-m", "mlx_lm", "generate",
        "--model", "microsoft/Phi-3-mini-4k-instruct",
        "--adapter-path", adapter_path,
        "--max-tokens", str(max_tokens),
        "--prompt", prompt
    ]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        return result.stdout
    except subprocess.TimeoutExpired:
        return "TIMEOUT"


def main():
    parser = argparse.ArgumentParser(description="Test design-analyst model")
    parser.add_argument("--model", default="models/design-analyst-v4-q4.gguf",
                        help="Path to GGUF model")
    parser.add_argument("--use-ollama", action="store_true",
                        help="Use Ollama instead of llama-cli")
    parser.add_argument("--ollama-model", default="design-analyst",
                        help="Ollama model name")
    parser.add_argument("--use-mlx", action="store_true",
                        help="Use MLX adapter directly (skip GGUF)")
    parser.add_argument("--adapter-path", default="adapters/design-analyst-v4",
                        help="MLX adapter path (for --use-mlx)")
    parser.add_argument("--max-tokens", type=int, default=400)
    parser.add_argument("--test", type=int, help="Run specific test (1-6)")
    args = parser.parse_args()

    print("=" * 70)
    print("Design Analyst Model Test Suite")
    print("=" * 70)

    if args.use_mlx:
        print(f"Using MLX adapter: {args.adapter_path}")
    elif args.use_ollama:
        print(f"Using Ollama model: {args.ollama_model}")
    else:
        print(f"Using GGUF model: {args.model}")

    print()

    # Select tests
    tests = TEST_PROMPTS
    if args.test:
        tests = [TEST_PROMPTS[args.test - 1]]

    results = []

    for i, test in enumerate(tests, 1):
        print(f"\n{'='*70}")
        print(f"Test {i}: {test['name']}")
        print(f"{'='*70}")
        print(f"Prompt: {test['prompt'][:100]}...")
        print(f"Expected: {test['expected']}")
        print("-" * 70)

        # Run test
        if args.use_mlx:
            output = test_with_mlx(args.adapter_path, test['prompt'], args.max_tokens)
        elif args.use_ollama:
            output = test_with_ollama(args.ollama_model, test['prompt'])
        else:
            output = test_with_llama_cpp(args.model, test['prompt'], args.max_tokens)

        print("Output:")
        print(output)

        # Basic validation
        passed = False
        if "sequenceDiagram" in test['name'].lower() and "sequenceDiagram" in output:
            passed = True
        elif "flowchart" in test['name'].lower() and ("flowchart" in output or "graph" in output):
            passed = True
        elif "class" in test['name'].lower() and "classDiagram" in output:
            passed = True
        elif "ticket" in test['name'].lower() or "analysis" in test['name'].lower():
            passed = len(output) > 100  # Just check it generated something
        else:
            passed = len(output) > 50

        status = "✅ PASS" if passed else "⚠️ CHECK"
        print(f"\nStatus: {status}")
        results.append((test['name'], passed))

    # Summary
    print("\n" + "=" * 70)
    print("Summary")
    print("=" * 70)

    passed = sum(1 for _, p in results if p)
    total = len(results)

    for name, p in results:
        status = "✅" if p else "⚠️"
        print(f"  {status} {name}")

    print(f"\nTotal: {passed}/{total} passed")

    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main())