"""
Merge LoRA into base model and save for GGUF conversion.

Usage:
    python merge_for_gguf.py

Then convert with llama.cpp:
    python ~/llama.cpp/convert_hf_to_gguf.py ./models/design-analyst-merged --outfile ./models/design-analyst.gguf --outtype f16

Optionally quantize:
    ~/llama.cpp/llama-quantize ./models/design-analyst.gguf ./models/design-analyst-q4.gguf q4_k_m
"""

import os
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel

BASE_MODEL_ID = "microsoft/Phi-3-mini-4k-instruct"
LORA_PATH = "../checkpoints/design-analyst-lora"
MERGED_PATH = "./models/design-analyst-merged"

os.makedirs("./models", exist_ok=True)

print("Loading base model...")
base_model = AutoModelForCausalLM.from_pretrained(
    BASE_MODEL_ID,
    torch_dtype=torch.float16,
    trust_remote_code=True,
    device_map="cpu",  # Keep on CPU for saving
)

print(f"Loading LoRA from {LORA_PATH}...")
model = PeftModel.from_pretrained(base_model, LORA_PATH, local_files_only=True)

print("Merging LoRA weights into base model...")
merged_model = model.merge_and_unload()

print(f"Saving merged model to {MERGED_PATH}...")
merged_model.save_pretrained(MERGED_PATH, safe_serialization=True)

print("Saving tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL_ID)
tokenizer.save_pretrained(MERGED_PATH)

print("""
✅ Merged model saved!

Next steps:

1. Convert to GGUF:
   python ~/llama.cpp/convert_hf_to_gguf.py ./models/design-analyst-merged --outfile ./models/design-analyst-f16.gguf --outtype f16

2. Quantize to Q4 (smaller, ~2GB):
   ~/llama.cpp/llama-quantize ./models/design-analyst-f16.gguf ./models/design-analyst-q4.gguf q4_k_m

3. Test with llama.cpp:
   ~/llama.cpp/llama-cli -m ./models/design-analyst-q4.gguf -p "<|system|>You are a software design analyst.<|end|><|user|>A ticket has 47 mentions but 0 PRs after 45 days.<|end|><|assistant|>" -n 200
""")