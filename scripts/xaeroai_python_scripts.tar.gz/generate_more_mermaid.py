#!/usr/bin/env python3
"""
Generate more Mermaid examples in smaller batches to avoid truncation.
Appends to existing file.
"""

import json
import time
from pathlib import Path
from anthropic import Anthropic

OUTPUT_FILE = Path("data/patterns/mermaid_examples.jsonl")
client = Anthropic()

SYSTEM_PROMPT = """You are a software design analyst for Cyan, a design-first collaboration tool. You have deep expertise in:
- Design patterns (GoF, enterprise, microservices, Rust idioms)
- Software architecture (clean architecture, DDD, CQRS, event sourcing)
- UML and diagram generation using Mermaid syntax
- Project health analysis from integration data

When asked for diagrams, output valid Mermaid syntax in a code block. Be specific, actionable, and concise."""

# Smaller batches - 10 examples each, more categories
CATEGORIES = [
    # SEQUENCE DIAGRAMS - need more of these
    {
        "category": "seq_auth_1",
        "prompt": "Generate 10 training examples for SEQUENCE DIAGRAMS showing OAuth2, JWT refresh, and SSO flows. Use Mermaid sequenceDiagram with participants, alt blocks, and notes."
    },
    {
        "category": "seq_auth_2",
        "prompt": "Generate 10 training examples for SEQUENCE DIAGRAMS showing MFA, passwordless login, and session management. Use Mermaid sequenceDiagram syntax."
    },
    {
        "category": "seq_api_1",
        "prompt": "Generate 10 training examples for SEQUENCE DIAGRAMS showing REST API CRUD operations, error handling, and pagination. Use Mermaid sequenceDiagram."
    },
    {
        "category": "seq_api_2",
        "prompt": "Generate 10 training examples for SEQUENCE DIAGRAMS showing WebSocket lifecycle, GraphQL queries, and webhook delivery. Use Mermaid sequenceDiagram."
    },
    {
        "category": "seq_distributed_1",
        "prompt": "Generate 10 training examples for SEQUENCE DIAGRAMS showing Saga pattern, event sourcing flow, and CQRS command handling. Use Mermaid sequenceDiagram with failure paths."
    },
    {
        "category": "seq_distributed_2",
        "prompt": "Generate 10 training examples for SEQUENCE DIAGRAMS showing circuit breaker, retry with backoff, and P2P gossip sync. Use Mermaid sequenceDiagram."
    },

    # CLASS DIAGRAMS - need more
    {
        "category": "class_gof_1",
        "prompt": "Generate 10 training examples for CLASS DIAGRAMS of creational patterns: Singleton, Factory Method, Abstract Factory, Builder, Prototype. Use Mermaid classDiagram with relationships."
    },
    {
        "category": "class_gof_2",
        "prompt": "Generate 10 training examples for CLASS DIAGRAMS of structural patterns: Adapter, Bridge, Composite, Decorator, Facade, Proxy. Use Mermaid classDiagram."
    },
    {
        "category": "class_gof_3",
        "prompt": "Generate 10 training examples for CLASS DIAGRAMS of behavioral patterns: Observer, Strategy, Command, State, Template Method. Use Mermaid classDiagram."
    },
    {
        "category": "class_rust_1",
        "prompt": "Generate 10 training examples for CLASS DIAGRAMS showing Rust patterns: trait objects, newtype, typestate builder. Show traits as interfaces. Include brief Rust code."
    },
    {
        "category": "class_enterprise_1",
        "prompt": "Generate 10 training examples for CLASS DIAGRAMS of Repository, Unit of Work, and Service Layer patterns. Use Mermaid classDiagram."
    },
    {
        "category": "class_enterprise_2",
        "prompt": "Generate 10 training examples for CLASS DIAGRAMS of Aggregate, Entity, Value Object, and Domain Event patterns. Use Mermaid classDiagram."
    },

    # FLOWCHARTS - add more variety
    {
        "category": "flow_error",
        "prompt": "Generate 10 training examples for FLOWCHARTS showing error handling, retry logic, and circuit breaker decisions. Use Mermaid flowchart with styled nodes."
    },
    {
        "category": "flow_cicd",
        "prompt": "Generate 10 training examples for FLOWCHARTS showing CI/CD pipelines, deployment decisions, and rollback flows. Use Mermaid flowchart."
    },
    {
        "category": "flow_validation",
        "prompt": "Generate 10 training examples for FLOWCHARTS showing request validation, auth checks, and feature flag routing. Use Mermaid flowchart."
    },

    # STATE DIAGRAMS - add more
    {
        "category": "state_entities",
        "prompt": "Generate 10 training examples for STATE DIAGRAMS showing Order, Payment, and Subscription lifecycles. Use Mermaid stateDiagram-v2 with nested states."
    },
    {
        "category": "state_connections",
        "prompt": "Generate 10 training examples for STATE DIAGRAMS showing WebSocket, TCP connection, and HTTP request states. Use Mermaid stateDiagram-v2."
    },

    # ER DIAGRAMS - add more
    {
        "category": "er_ecommerce",
        "prompt": "Generate 10 training examples for ER DIAGRAMS of e-commerce domains: orders, products, users, inventory. Use Mermaid erDiagram with proper relationships."
    },
    {
        "category": "er_saas",
        "prompt": "Generate 10 training examples for ER DIAGRAMS of SaaS domains: multi-tenant, subscriptions, audit logs, permissions. Use Mermaid erDiagram."
    },

    # ARCHITECTURE
    {
        "category": "arch_micro",
        "prompt": "Generate 10 training examples for ARCHITECTURE DIAGRAMS showing microservices, API gateway, service mesh layouts. Use Mermaid flowchart with subgraphs."
    },
    {
        "category": "arch_layers",
        "prompt": "Generate 10 training examples for ARCHITECTURE DIAGRAMS showing clean architecture, hexagonal architecture, and layered architecture. Use Mermaid flowchart with subgraphs."
    },

    # MIXED - health + diagram
    {
        "category": "health_diagram_1",
        "prompt": """Generate 10 training examples where user provides ticket health context and asks for a diagram.

User format: <context>Ticket: X, Slack mentions: N, PRs: M, Days open: D</context> Question about architecture.

Response: Health analysis with emoji (red/yellow/green), then relevant Mermaid diagram."""
    },
    {
        "category": "health_diagram_2",
        "prompt": """Generate 10 training examples where user provides project context and asks for a sequence diagram.

User format: <context>Feature: X, discussing for N days, no implementation</context> Ask for flow diagram.

Response: Health analysis, then Mermaid sequenceDiagram showing proposed flow."""
    },
]


def generate_examples(category: dict) -> list:
    """Generate 10 examples for a category."""
    prompt = f"""{category["prompt"]}

Output ONLY a valid JSON array with exactly 10 objects.
Each object must have "instruction" and "output" keys.
Keep each example concise (under 800 chars per field).
Start with [ and end with ]."""

    try:
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=8000,
            messages=[{"role": "user", "content": prompt}]
        )

        text = response.content[0].text.strip()
        start = text.find('[')
        end = text.rfind(']') + 1

        if start >= 0 and end > start:
            json_str = text[start:end]
            try:
                return json.loads(json_str)
            except json.JSONDecodeError:
                json_str = json_str.replace(",]", "]").replace(",\n]", "\n]")
                try:
                    return json.loads(json_str)
                except:
                    print(f"    JSON error, skipping")
                    return []
        return []
    except Exception as e:
        print(f"    Error: {e}")
        return []


def convert_to_messages(example: dict) -> dict:
    return {
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": example["instruction"]},
            {"role": "assistant", "content": example["output"]}
        ]
    }


def main():
    # Load existing
    existing = []
    if OUTPUT_FILE.exists():
        with open(OUTPUT_FILE) as f:
            for line in f:
                if line.strip():
                    existing.append(json.loads(line))
    print(f"Existing examples: {len(existing)}")

    new_examples = []

    print(f"\nGenerating {len(CATEGORIES)} batches of 10 examples each...")
    print(f"Target: ~{len(CATEGORIES) * 10} new examples\n")

    for i, category in enumerate(CATEGORIES):
        print(f"[{i+1}/{len(CATEGORIES)}] {category['category']}", end=" ")

        examples = generate_examples(category)
        print(f"→ {len(examples)}")

        new_examples.extend(examples)

        # Rate limit - 45s should be safe for smaller batches
        if i < len(CATEGORIES) - 1:
            time.sleep(45)

    print(f"\nNew examples: {len(new_examples)}")

    # Convert and combine
    formatted = [convert_to_messages(ex) for ex in new_examples if ex.get("instruction") and ex.get("output")]
    all_examples = existing + formatted

    print(f"Total examples: {len(all_examples)}")

    # Save
    with open(OUTPUT_FILE, "w") as f:
        for ex in all_examples:
            f.write(json.dumps(ex) + "\n")

    print(f"Saved to {OUTPUT_FILE}")

    # Stats
    content = str(all_examples)
    print("\nDiagram types:")
    for dtype in ["classDiagram", "sequenceDiagram", "flowchart", "stateDiagram", "erDiagram"]:
        print(f"  {dtype}: {content.count(dtype)}")


if __name__ == "__main__":
    main()