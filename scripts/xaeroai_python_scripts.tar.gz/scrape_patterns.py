#!/usr/bin/env python3
"""
Scrape design patterns from key sources.
Output: data/patterns/raw_patterns.json
"""

import httpx
from bs4 import BeautifulSoup
import json
import time
from dataclasses import dataclass, asdict
from typing import Optional
from pathlib import Path

@dataclass
class PatternData:
    name: str
    category: str           # "gof", "fowler", "microservices", "rust", "go"
    subcategory: str        # "creational", "structural", "behavioral", etc.
    problem: str            # What problem it solves
    solution: str           # How it solves it
    code_example: Optional[str]
    when_to_use: list[str]
    when_not_to_use: list[str]
    language: Optional[str] # "rust", "python", "java", "go", "general"
    source_url: str


class PatternScraper:
    def __init__(self, output_dir: str = "data/patterns"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.client = httpx.Client(
            timeout=30,
            headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)"}
        )
        self.patterns: list[PatternData] = []

    def scrape_all(self):
        """Scrape all sources"""
        print("=== Scraping Refactoring Guru (GoF) ===")
        self.scrape_refactoring_guru()

        print("\n=== Scraping Martin Fowler Catalog ===")
        self.scrape_fowler_catalog()

        print("\n=== Scraping Microservices.io ===")
        self.scrape_microservices_io()

        print("\n=== Scraping Rust Patterns ===")
        self.scrape_rust_patterns()

        print("\n=== Scraping Go Patterns ===")
        self.scrape_go_patterns()

        self.save()
        print(f"\n=== Done! Scraped {len(self.patterns)} patterns ===")

    def scrape_refactoring_guru(self):
        """GoF patterns from refactoring.guru"""
        base_url = "https://refactoring.guru"

        # Pattern URLs organized by category
        patterns = {
            "creational": [
                "factory-method", "abstract-factory", "builder",
                "prototype", "singleton"
            ],
            "structural": [
                "adapter", "bridge", "composite", "decorator",
                "facade", "flyweight", "proxy"
            ],
            "behavioral": [
                "chain-of-responsibility", "command", "iterator",
                "mediator", "memento", "observer", "state",
                "strategy", "template-method", "visitor"
            ]
        }

        for subcategory, pattern_list in patterns.items():
            for pattern_slug in pattern_list:
                url = f"{base_url}/design-patterns/{pattern_slug}"
                try:
                    print(f"  Fetching: {pattern_slug}")
                    resp = self.client.get(url)
                    resp.raise_for_status()
                    soup = BeautifulSoup(resp.text, "html.parser")

                    # Extract pattern name
                    name_elem = soup.select_one("h1.title")
                    name = name_elem.text.strip() if name_elem else pattern_slug.replace("-", " ").title()

                    # Extract intent/problem
                    intent_elem = soup.select_one("div.intent p")
                    problem = intent_elem.text.strip() if intent_elem else ""

                    # Extract solution (first few paragraphs of content)
                    solution_parts = []
                    content_div = soup.select_one("div.content")
                    if content_div:
                        for p in content_div.select("p")[:3]:
                            solution_parts.append(p.text.strip())
                    solution = " ".join(solution_parts)

                    # Extract code example (Python preferred)
                    code_example = None
                    code_blocks = soup.select("pre code")
                    for block in code_blocks:
                        code_text = block.text.strip()
                        if len(code_text) > 50:
                            code_example = code_text[:1500]  # Limit size
                            break

                    # Extract applicability (when to use)
                    when_to_use = []
                    applicability = soup.select("div.applicability li")
                    for li in applicability[:5]:
                        when_to_use.append(li.text.strip()[:200])

                    self.patterns.append(PatternData(
                        name=name,
                        category="gof",
                        subcategory=subcategory,
                        problem=problem[:500],
                        solution=solution[:1000],
                        code_example=code_example,
                        when_to_use=when_to_use,
                        when_not_to_use=[],
                        language="general",
                        source_url=url
                    ))

                    time.sleep(0.5)  # Be nice to servers

                except Exception as e:
                    print(f"    Error scraping {pattern_slug}: {e}")

    def scrape_fowler_catalog(self):
        """Enterprise patterns from martinfowler.com"""
        base_url = "https://martinfowler.com/eaaCatalog"

        # Key enterprise patterns
        patterns = [
            "domainModel", "transactionScript", "tableModule",
            "serviceLayer", "repository", "dataMapper",
            "activeRecord", "unitOfWork", "identityMap",
            "lazyLoad", "gateway", "mapper",
            "frontController", "pageController", "templateView",
            "transformView", "applicationController",
            "dataTransferObject", "remoteFacade",
            "dependencyInjection", "plugin", "registry"
        ]

        for pattern_slug in patterns[:20]:  # Top 20 for today
            url = f"{base_url}/{pattern_slug}.html"
            try:
                print(f"  Fetching: {pattern_slug}")
                resp = self.client.get(url)
                resp.raise_for_status()
                soup = BeautifulSoup(resp.text, "html.parser")

                # Extract title
                title_elem = soup.select_one("h1")
                name = title_elem.text.strip() if title_elem else pattern_slug

                # Extract content paragraphs
                content_parts = []
                for p in soup.select("p")[:5]:
                    text = p.text.strip()
                    if len(text) > 50:
                        content_parts.append(text)

                problem = content_parts[0] if content_parts else ""
                solution = " ".join(content_parts[1:3]) if len(content_parts) > 1 else ""

                # Extract code if present
                code_example = None
                pre_blocks = soup.select("pre")
                for pre in pre_blocks:
                    code_text = pre.text.strip()
                    if len(code_text) > 50:
                        code_example = code_text[:1500]
                        break

                self.patterns.append(PatternData(
                    name=name,
                    category="fowler",
                    subcategory="enterprise",
                    problem=problem[:500],
                    solution=solution[:1000],
                    code_example=code_example,
                    when_to_use=[],
                    when_not_to_use=[],
                    language="general",
                    source_url=url
                ))

                time.sleep(0.5)

            except Exception as e:
                print(f"    Error scraping {pattern_slug}: {e}")

    def scrape_microservices_io(self):
        """Microservices patterns"""
        base_url = "https://microservices.io/patterns"

        patterns = [
            ("decomposition/decompose-by-business-capability", "decomposition"),
            ("decomposition/decompose-by-subdomain", "decomposition"),
            ("data/database-per-service", "data"),
            ("data/saga", "data"),
            ("data/cqrs", "data"),
            ("data/event-sourcing", "data"),
            ("communication-style/messaging", "communication"),
            ("communication-style/rpi", "communication"),
            ("reliability/circuit-breaker", "reliability"),
            ("observability/distributed-tracing", "observability"),
            ("observability/health-check-api", "observability"),
            ("security/access-token", "security"),
            ("deployment/service-per-container", "deployment"),
            ("deployment/sidecar", "deployment"),
            ("apigateway", "api"),
            ("client-side-discovery", "discovery"),
            ("server-side-discovery", "discovery"),
            ("service-registry", "discovery"),
            ("externalized-configuration", "config"),
        ]

        for pattern_path, subcategory in patterns:
            pattern_slug = pattern_path.split("/")[-1]
            url = f"{base_url}/{pattern_path}.html"
            try:
                print(f"  Fetching: {pattern_slug}")
                resp = self.client.get(url)
                resp.raise_for_status()
                soup = BeautifulSoup(resp.text, "html.parser")

                # Extract title
                title_elem = soup.select_one("h1")
                name = title_elem.text.strip() if title_elem else pattern_slug.replace("-", " ").title()

                # Extract problem/context
                problem = ""
                problem_section = soup.find("h2", string=lambda t: t and "Problem" in t)
                if problem_section:
                    next_p = problem_section.find_next("p")
                    if next_p:
                        problem = next_p.text.strip()

                # Extract solution
                solution = ""
                solution_section = soup.find("h2", string=lambda t: t and "Solution" in t)
                if solution_section:
                    next_p = solution_section.find_next("p")
                    if next_p:
                        solution = next_p.text.strip()

                # Fallback to general content
                if not problem or not solution:
                    paragraphs = soup.select("article p, div.content p")
                    texts = [p.text.strip() for p in paragraphs if len(p.text.strip()) > 50]
                    if texts:
                        problem = texts[0] if not problem else problem
                        solution = texts[1] if len(texts) > 1 and not solution else solution

                self.patterns.append(PatternData(
                    name=name,
                    category="microservices",
                    subcategory=subcategory,
                    problem=problem[:500],
                    solution=solution[:1000],
                    code_example=None,
                    when_to_use=[],
                    when_not_to_use=[],
                    language="general",
                    source_url=url
                ))

                time.sleep(0.5)

            except Exception as e:
                print(f"    Error scraping {pattern_slug}: {e}")

    def scrape_rust_patterns(self):
        """Rust idioms and patterns"""
        base_url = "https://rust-unofficial.github.io/patterns"

        patterns = [
            ("idioms/coercion-arguments", "idioms", "Coercion Arguments"),
            ("idioms/concat-format", "idioms", "Concatenation with format!"),
            ("idioms/constructor", "idioms", "Constructor Pattern"),
            ("idioms/default", "idioms", "Default Trait"),
            ("idioms/deref", "idioms", "Deref Polymorphism"),
            ("idioms/dtor-finally", "idioms", "Finalisation in Destructors"),
            ("idioms/mem-replace", "idioms", "mem::replace"),
            ("idioms/on-stack-dyn-dispatch", "idioms", "On-Stack Dynamic Dispatch"),
            ("idioms/option-iter", "idioms", "Option Iterator"),
            ("idioms/pass-var-to-closure", "idioms", "Pass Variables to Closure"),
            ("idioms/priv-extend", "idioms", "Private Field Extension"),
            ("idioms/temporary-mutability", "idioms", "Temporary Mutability"),
            ("patterns/behavioural/newtype", "behavioral", "Newtype Pattern"),
            ("patterns/behavioural/RAII", "behavioral", "RAII Guards"),
            ("patterns/behavioural/strategy", "behavioral", "Strategy Pattern"),
            ("patterns/creational/builder", "creational", "Builder Pattern"),
            ("patterns/creational/fold", "creational", "Fold Pattern"),
            ("patterns/structural/compose-structs", "structural", "Compose Structs"),
            ("patterns/structural/small-crates", "structural", "Small Crates"),
            ("anti_patterns/deny-warnings", "antipatterns", "Deny Warnings"),
        ]

        for path, subcategory, name in patterns:
            url = f"{base_url}/{path}.html"
            try:
                print(f"  Fetching: {name}")
                resp = self.client.get(url)
                resp.raise_for_status()
                soup = BeautifulSoup(resp.text, "html.parser")

                # Extract content from main
                main_content = soup.select_one("main")
                if not main_content:
                    main_content = soup

                # Get description paragraphs
                paragraphs = main_content.select("p")
                texts = [p.text.strip() for p in paragraphs if len(p.text.strip()) > 30]

                problem = texts[0] if texts else ""
                solution = " ".join(texts[1:3]) if len(texts) > 1 else ""

                # Get code example
                code_example = None
                code_blocks = main_content.select("pre code, code.language-rust")
                for block in code_blocks:
                    code_text = block.text.strip()
                    if len(code_text) > 30:
                        code_example = code_text[:1500]
                        break

                self.patterns.append(PatternData(
                    name=name,
                    category="rust",
                    subcategory=subcategory,
                    problem=problem[:500],
                    solution=solution[:1000],
                    code_example=code_example,
                    when_to_use=[],
                    when_not_to_use=[],
                    language="rust",
                    source_url=url
                ))

                time.sleep(0.3)

            except Exception as e:
                print(f"    Error scraping {name}: {e}")

    def scrape_go_patterns(self):
        """Go patterns - manually curated since source varies"""

        # Effective Go patterns (curated content)
        go_patterns = [
            {
                "name": "Error Wrapping",
                "subcategory": "error-handling",
                "problem": "Errors lose context as they propagate up the call stack.",
                "solution": "Wrap errors with context using fmt.Errorf and %w verb. This preserves the error chain while adding context at each level.",
                "code_example": '''if err != nil {
    return fmt.Errorf("failed to process order %s: %w", orderID, err)
}

// Unwrap later
if errors.Is(err, ErrNotFound) {
    // handle not found
}''',
                "when_to_use": ["When propagating errors up", "When context helps debugging"]
            },
            {
                "name": "Functional Options",
                "subcategory": "creational",
                "problem": "Constructors with many optional parameters become unwieldy.",
                "solution": "Use variadic functions that accept option functions. Each option modifies the config.",
                "code_example": '''type Option func(*Server)

func WithTimeout(d time.Duration) Option {
    return func(s *Server) { s.timeout = d }
}

func NewServer(opts ...Option) *Server {
    s := &Server{timeout: defaultTimeout}
    for _, opt := range opts {
        opt(s)
    }
    return s
}

// Usage
srv := NewServer(WithTimeout(30*time.Second))''',
                "when_to_use": ["Many optional parameters", "Want readable construction"]
            },
            {
                "name": "Interface Segregation",
                "subcategory": "structural",
                "problem": "Large interfaces force implementations to provide methods they don't need.",
                "solution": "Define small, focused interfaces. Accept interfaces, return structs. Let implementations satisfy only what they need.",
                "code_example": '''// Good: small interfaces
type Reader interface {
    Read(p []byte) (n int, err error)
}

type Writer interface {
    Write(p []byte) (n int, err error)
}

// Combine when needed
type ReadWriter interface {
    Reader
    Writer
}

// Accept interface
func Process(r Reader) error { ... }''',
                "when_to_use": ["Defining contracts", "Enabling testability"]
            },
            {
                "name": "Context Propagation",
                "subcategory": "concurrency",
                "problem": "Need to pass deadlines, cancellation signals, and request-scoped values through call chain.",
                "solution": "Pass context.Context as first parameter. Use it for cancellation, timeouts, and request-scoped data.",
                "code_example": '''func ProcessOrder(ctx context.Context, order *Order) error {
    // Check cancellation
    select {
    case <-ctx.Done():
        return ctx.Err()
    default:
    }
    
    // Pass to downstream
    if err := validateOrder(ctx, order); err != nil {
        return err
    }
    
    return chargePayment(ctx, order)
}''',
                "when_to_use": ["HTTP handlers", "Background jobs", "Any cancellable operation"]
            },
            {
                "name": "Table-Driven Tests",
                "subcategory": "testing",
                "problem": "Repetitive test code with slight variations.",
                "solution": "Define test cases as a slice of structs. Loop through and run each case.",
                "code_example": '''func TestAdd(t *testing.T) {
    tests := []struct {
        name     string
        a, b     int
        expected int
    }{
        {"positive", 1, 2, 3},
        {"negative", -1, -2, -3},
        {"zero", 0, 0, 0},
    }
    
    for _, tc := range tests {
        t.Run(tc.name, func(t *testing.T) {
            got := Add(tc.a, tc.b)
            if got != tc.expected {
                t.Errorf("got %d, want %d", got, tc.expected)
            }
        })
    }
}''',
                "when_to_use": ["Multiple similar test cases", "Testing edge cases"]
            },
            {
                "name": "Fan-Out Fan-In",
                "subcategory": "concurrency",
                "problem": "Need to parallelize work and collect results.",
                "solution": "Fan-out: start multiple goroutines. Fan-in: merge results into single channel.",
                "code_example": '''func fanOut(ctx context.Context, input <-chan int, workers int) []<-chan int {
    channels := make([]<-chan int, workers)
    for i := 0; i < workers; i++ {
        channels[i] = worker(ctx, input)
    }
    return channels
}

func fanIn(ctx context.Context, channels ...<-chan int) <-chan int {
    out := make(chan int)
    var wg sync.WaitGroup
    for _, ch := range channels {
        wg.Add(1)
        go func(c <-chan int) {
            defer wg.Done()
            for v := range c {
                select {
                case out <- v:
                case <-ctx.Done():
                    return
                }
            }
        }(ch)
    }
    go func() { wg.Wait(); close(out) }()
    return out
}''',
                "when_to_use": ["Parallel processing", "I/O bound work"]
            },
            {
                "name": "Channel Pipeline",
                "subcategory": "concurrency",
                "problem": "Need to process data through multiple stages.",
                "solution": "Each stage reads from input channel, processes, writes to output channel.",
                "code_example": '''func generate(nums ...int) <-chan int {
    out := make(chan int)
    go func() {
        for _, n := range nums {
            out <- n
        }
        close(out)
    }()
    return out
}

func square(in <-chan int) <-chan int {
    out := make(chan int)
    go func() {
        for n := range in {
            out <- n * n
        }
        close(out)
    }()
    return out
}

// Usage: for n := range square(generate(1, 2, 3)) { ... }''',
                "when_to_use": ["Stream processing", "Multi-stage transformation"]
            },
            {
                "name": "Struct Embedding",
                "subcategory": "structural",
                "problem": "Want to reuse functionality without inheritance.",
                "solution": "Embed structs to promote their methods. Composition over inheritance.",
                "code_example": '''type Logger struct{}
func (l *Logger) Log(msg string) { fmt.Println(msg) }

type Server struct {
    Logger  // Embedded
    addr string
}

// Server.Log() is now available
srv := &Server{addr: ":8080"}
srv.Log("starting")''',
                "when_to_use": ["Code reuse", "Mixin-like behavior"]
            },
        ]

        for p in go_patterns:
            self.patterns.append(PatternData(
                name=p["name"],
                category="go",
                subcategory=p["subcategory"],
                problem=p["problem"],
                solution=p["solution"],
                code_example=p["code_example"],
                when_to_use=p.get("when_to_use", []),
                when_not_to_use=p.get("when_not_to_use", []),
                language="go",
                source_url="https://go.dev/doc/effective_go"
            ))

        print(f"  Added {len(go_patterns)} Go patterns")

    def save(self):
        """Save scraped patterns to JSON"""
        output_file = self.output_dir / "raw_patterns.json"
        with open(output_file, "w") as f:
            json.dump([asdict(p) for p in self.patterns], f, indent=2)
        print(f"Saved to {output_file}")


if __name__ == "__main__":
    scraper = PatternScraper()
    scraper.scrape_all()