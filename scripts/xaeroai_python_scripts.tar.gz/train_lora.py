"""
LoRA fine-tuning for Design Analyst model.

Usage:
    python train_lora.py

Output:
    - checkpoints/design-analyst-lora/  (LoRA weights)
"""

import os
import torch
from datasets import load_dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from trl import SFTTrainer

# =============================================================================
# Config
# =============================================================================

MODEL_ID = "microsoft/Phi-3-mini-4k-instruct"
DATA_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "../data/design_analyst/train.jsonl"))
OUTPUT_DIR = "./checkpoints/design-analyst-lora"

# LoRA parameters
LORA_R = 16              # Rank - higher = more capacity, more memory
LORA_ALPHA = 32          # Scaling factor
LORA_DROPOUT = 0.05

# Training parameters
EPOCHS = 3              # Was first 3 then 15 then 3
LEARNING_RATE = 2e-4     # Was 2e-4 then 5e-4 then 2e-4
BATCH_SIZE = 1           # Small for memory, we use gradient accumulation
GRADIENT_ACCUMULATION = 4  # Effective batch = 1 * 4 = 4
MAX_SEQ_LENGTH = 2048

# =============================================================================
# Load Model
# =============================================================================

print("Loading tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
tokenizer.pad_token = tokenizer.eos_token
tokenizer.padding_side = "right"

print("Loading model...")
model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID,
    torch_dtype=torch.float16,
    device_map="auto",
    trust_remote_code=True,
)

# =============================================================================
# Setup LoRA
# =============================================================================

print("Setting up LoRA...")

lora_config = LoraConfig(
    r=LORA_R,
    lora_alpha=LORA_ALPHA,
    lora_dropout=LORA_DROPOUT,
    bias="none",
    task_type="CAUSAL_LM",
    # Target the attention layers
    target_modules=[
        "qkv_proj",   # Phi-3 combines Q, K, V into one
        "o_proj",     # Output projection
        "gate_up_proj",  # FFN
        "down_proj",     # FFN
    ],
)

model = get_peft_model(model, lora_config)
model.print_trainable_parameters()

# =============================================================================
# Load Dataset
# =============================================================================

print(f"Loading dataset from {DATA_PATH}...")

dataset = load_dataset("json", data_files=DATA_PATH, split="train")

print(f"Loaded {len(dataset)} examples")
print(f"Example: {dataset[0]['messages'][1]['content'][:100]}...")

# =============================================================================
# Format for Phi-3
# =============================================================================

def format_chat(example):
    """Convert messages to Phi-3 chat format."""
    messages = example["messages"]
    text = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=False
    )
    return {"text": text}

dataset = dataset.map(format_chat)
print("\n" + "="*60)
print("FORMATTED EXAMPLE:")
print("="*60)
print(dataset[0]["text"][:2000])
print("="*60 + "\n")

# =============================================================================
# Training Arguments
# =============================================================================

training_args = TrainingArguments(
    output_dir=OUTPUT_DIR,
    num_train_epochs=EPOCHS,
    per_device_train_batch_size=BATCH_SIZE,
    gradient_accumulation_steps=GRADIENT_ACCUMULATION,
    learning_rate=LEARNING_RATE,
    weight_decay=0.01,
    warmup_ratio=0.1,
    logging_steps=5,
    save_strategy="epoch",
    fp16=True,
    optim="adamw_torch",
    report_to="none",  # Set to "wandb" if you want logging
)

# =============================================================================
# Train
# =============================================================================

print("Starting training...")

trainer = SFTTrainer(
    model=model,
    args=training_args,
    train_dataset=dataset,
    processing_class=tokenizer,
)

trainer.train()

# =============================================================================
# Save
# =============================================================================

print(f"Saving LoRA weights to {OUTPUT_DIR}...")
model.save_pretrained(OUTPUT_DIR)
tokenizer.save_pretrained(OUTPUT_DIR)

print("✅ Training complete!")
print(f"LoRA weights saved to: {OUTPUT_DIR}")
print("\nNext: Run test_lora.py to verify the training worked.")