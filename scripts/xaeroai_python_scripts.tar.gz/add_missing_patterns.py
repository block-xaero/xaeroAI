#!/usr/bin/env python3
"""
Add missing patterns that failed to scrape.
Run after scrape_patterns.py to patch in missing ones.
"""

import json
from pathlib import Path

MISSING_PATTERNS = [
    {
        "name": "Constructor",
        "category": "rust",
        "subcategory": "idioms",
        "problem": "Rust does not have constructors as a language construct like other OOP languages.",
        "solution": "Use an associated function `new` to create an object. This is a convention in Rust. For default values, implement the Default trait which can be derived for structs whose fields all implement Default.",
        "code_example": '''pub struct Second {
    value: u64,
}

impl Second {
    // Constructor - associated function, no self
    pub fn new(value: u64) -> Self {
        Self { value }
    }
    
    pub fn value(&self) -> u64 {
        self.value
    }
}

// Default constructor via trait
impl Default for Second {
    fn default() -> Self {
        Self { value: 0 }
    }
}

// Usage
let s = Second::new(42);
let s_default = Second::default();''',
        "when_to_use": [
            "Creating new instances of structs",
            "When you need custom initialization logic",
            "When Default trait is appropriate for zero/empty values"
        ],
        "when_not_to_use": [],
        "language": "rust",
        "source_url": "https://rust-unofficial.github.io/patterns/idioms/ctor.html"
    },
    {
        "name": "Dependency Injection",
        "category": "fowler",
        "subcategory": "enterprise",
        "problem": "Application classes need to use plugin implementations but shouldn't be tightly coupled to concrete implementations. Hard-coded dependencies make testing difficult and reduce flexibility.",
        "solution": "Instead of having application classes instantiate their dependencies directly, inject the dependencies from outside. This can be done via Constructor Injection (dependencies passed to constructor), Setter Injection (dependencies set via setter methods), or Interface Injection (dependency provides an injector method). This separates configuration from use and enables the Service Locator alternative.",
        "code_example": '''# Constructor Injection (preferred)
class MovieLister:
    def __init__(self, finder: MovieFinder):
        self.finder = finder  # Injected, not created here
    
    def movies_directed_by(self, director: str) -> list:
        all_movies = self.finder.find_all()
        return [m for m in all_movies if m.director == director]

# Configuration/Wiring (done at startup)
finder = CSVMovieFinder("movies.csv")  # or DBMovieFinder, APIMovieFinder
lister = MovieLister(finder)  # Inject the dependency

# Now MovieLister can be tested with a mock finder
class MockFinder:
    def find_all(self):
        return [Movie("Test", "Test Director")]

test_lister = MovieLister(MockFinder())''',
        "when_to_use": [
            "When you want to decouple application logic from concrete implementations",
            "When you need to swap implementations (testing, different environments)",
            "When following the Dependency Inversion Principle",
            "When configuration should be separate from use"
        ],
        "when_not_to_use": [
            "Simple applications where the overhead isn't justified",
            "When there's truly only one implementation ever"
        ],
        "language": "general",
        "source_url": "https://martinfowler.com/articles/injection.html"
    },
    {
        "name": "Service Locator",
        "category": "fowler",
        "subcategory": "enterprise",
        "problem": "Need to decouple application from concrete service implementations, but want explicit service lookup rather than injection.",
        "solution": "Create a central registry (Service Locator) that knows how to get hold of all services. Application code asks the locator for implementations explicitly. Unlike Dependency Injection where services 'appear' in the class, here the class actively requests the service.",
        "code_example": '''class ServiceLocator:
    _services = {}
    
    @classmethod
    def register(cls, interface, implementation):
        cls._services[interface] = implementation
    
    @classmethod
    def get(cls, interface):
        return cls._services.get(interface)

# Registration at startup
ServiceLocator.register(MovieFinder, CSVMovieFinder("movies.csv"))

# Usage in application code
class MovieLister:
    def __init__(self):
        # Explicit request - not injected
        self.finder = ServiceLocator.get(MovieFinder)
    
    def movies_directed_by(self, director: str) -> list:
        return [m for m in self.finder.find_all() if m.director == director]''',
        "when_to_use": [
            "When you prefer explicit service lookup over injection",
            "Simpler alternative to full DI container",
            "When services are truly global/singleton"
        ],
        "when_not_to_use": [
            "When testability is critical (harder to mock than DI)",
            "When you want clear dependency visibility"
        ],
        "language": "general",
        "source_url": "https://martinfowler.com/articles/injection.html"
    },
    {
        "name": "Inversion of Control",
        "category": "fowler",
        "subcategory": "enterprise",
        "problem": "In traditional programming, application code controls the flow - it calls libraries when needed. This creates tight coupling and reduces flexibility.",
        "solution": "Invert the control so that a framework calls your code rather than your code calling framework. Known as the Hollywood Principle: 'Don't call us, we'll call you.' Your code provides callbacks, handlers, or implementations that the framework invokes at the right time.",
        "code_example": '''# Traditional (you control flow)
def main():
    print("What is your name?")
    name = input()
    process_name(name)
    print("What is your quest?")
    quest = input()
    process_quest(quest)

# IoC (framework controls flow)
class MyHandler:
    def on_name_entered(self, name):
        process_name(name)
    
    def on_quest_entered(self, quest):
        process_quest(quest)

# Framework calls your methods when events occur
framework.register_handler(MyHandler())
framework.run()  # Framework now controls when your code runs''',
        "when_to_use": [
            "Building or using frameworks",
            "Event-driven architectures",
            "Plugin systems",
            "When you want extensibility points"
        ],
        "when_not_to_use": [
            "Simple scripts where direct control is clearer",
            "When debugging complexity would be too high"
        ],
        "language": "general",
        "source_url": "https://martinfowler.com/bliki/InversionOfControl.html"
    }
]


def main():
    patterns_file = Path("data/patterns/raw_patterns.json")

    if not patterns_file.exists():
        print(f"Error: {patterns_file} not found. Run scrape_patterns.py first.")
        return

    # Load existing patterns
    with open(patterns_file) as f:
        patterns = json.load(f)

    print(f"Loaded {len(patterns)} existing patterns")

    # Add missing patterns
    existing_names = {p["name"].lower() for p in patterns}
    added = 0

    for pattern in MISSING_PATTERNS:
        if pattern["name"].lower() not in existing_names:
            patterns.append(pattern)
            print(f"  Added: {pattern['name']}")
            added += 1
        else:
            print(f"  Skipped (exists): {pattern['name']}")

    # Save updated patterns
    with open(patterns_file, "w") as f:
        json.dump(patterns, f, indent=2)

    print(f"\nAdded {added} missing patterns")
    print(f"Total patterns: {len(patterns)}")


if __name__ == "__main__":
    main()