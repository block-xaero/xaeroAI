"""
Test with simple prompt for Slack demo.
"""

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel

BASE_MODEL_ID = "microsoft/Phi-3-mini-4k-instruct"
LORA_PATH = "../checkpoints/design-analyst-lora"

print("Loading...")
tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL_ID)
base_model = AutoModelForCausalLM.from_pretrained(
    BASE_MODEL_ID,
    torch_dtype=torch.float16,
    device_map="auto",
    trust_remote_code=True,
)
model = PeftModel.from_pretrained(base_model, LORA_PATH, local_files_only=True)

# Simple prompt like before
system_prompt = "You are a software design analyst. Be concise."
user_prompt = "A ticket has 47 Slack mentions but 0 PRs after 45 days. What's wrong?"

messages = [
    {"role": "system", "content": system_prompt},
    {"role": "user", "content": user_prompt},
]

formatted = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
inputs = tokenizer(formatted, return_tensors="pt").to(model.device)

print("Generating...")
outputs = model.generate(
    **inputs,
    max_new_tokens=300,
    do_sample=False,
    use_cache=False,
    pad_token_id=tokenizer.eos_token_id,
    eos_token_id=tokenizer.convert_tokens_to_ids("<|end|>"),
)

response = tokenizer.decode(outputs[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)

print("\n" + "="*60)
print("RESPONSE:")
print("="*60)
print(response)
print("="*60)