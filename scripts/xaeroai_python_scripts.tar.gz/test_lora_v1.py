"""
Test with exact same formatting as training.
"""

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel

BASE_MODEL_ID = "microsoft/Phi-3-mini-4k-instruct"
LORA_PATH = "../checkpoints/design-analyst-lora"

print("Loading...")
tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL_ID)
base_model = AutoModelForCausalLM.from_pretrained(
    BASE_MODEL_ID,
    torch_dtype=torch.float16,
    device_map="auto",
    trust_remote_code=True,
)
model = PeftModel.from_pretrained(base_model, LORA_PATH, local_files_only=True)

# Use EXACT same format as training data
system_prompt = "You are a software design analyst for Cyan, a design-first collaboration tool. Analyze project health from integration data (Slack mentions, Jira tickets, GitHub PRs, design boards). Identify design drift, over-architecture, stale designs, and missing context. Be specific and actionable."

user_prompt = """<context>
Ticket: TEST-999 "New Feature"
First mentioned: 60 days ago
Slack mentions: 85 (across 15 threads)
PRs linked: 0
Design board: "Feature Design" last edited 40 days ago
Contributors discussing: 8 people
</context>

Analyze this ticket's health."""

# Format exactly like training
messages = [
    {"role": "system", "content": system_prompt},
    {"role": "user", "content": user_prompt},
]

# Show what we're sending
formatted = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
print("\n" + "="*60)
print("INPUT TO MODEL:")
print("="*60)
print(formatted)
print("="*60)

# Generate
inputs = tokenizer(formatted, return_tensors="pt").to(model.device)

print("\nGenerating...")
outputs = model.generate(
    **inputs,
    max_new_tokens=400,
    do_sample=False,
    use_cache=False,
    pad_token_id=tokenizer.eos_token_id,
    eos_token_id=tokenizer.convert_tokens_to_ids("<|end|>"),
)

# Decode only new tokens
response = tokenizer.decode(outputs[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)

print("\n" + "="*60)
print("RESPONSE:")
print("="*60)
print(response)
print("="*60)