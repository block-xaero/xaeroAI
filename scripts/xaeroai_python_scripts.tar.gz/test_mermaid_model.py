#!/usr/bin/env python3
"""
Test script to validate Mermaid diagram generation from design-analyst model.
Generates diagrams, extracts Mermaid code, and validates syntax using mermaid-cli.

Usage:
    python scripts/test_mermaid_output.py
    python scripts/test_mermaid_output.py --adapter-path adapters/design-analyst-v4
    python scripts/test_mermaid_output.py --quick  # Run fewer tests
"""

import subprocess
import tempfile
import re
import json
import argparse
import sys
from pathlib import Path
from dataclasses import dataclass
from typing import Optional
import shutil

# Test prompts organized by diagram type
TEST_PROMPTS = {
    "sequenceDiagram": [
        "Create a Mermaid sequenceDiagram for user login",
        "Create a Mermaid sequenceDiagram for API request with retry logic",
        "Create a Mermaid sequenceDiagram for OAuth2 authorization flow",
    ],
    "classDiagram": [
        "Create a Mermaid classDiagram for Repository pattern",
        "Create a Mermaid classDiagram for Observer pattern",
        "Create a Mermaid classDiagram for a User and Order system",
    ],
    "flowchart": [
        "Create a Mermaid flowchart for error handling",
        "Create a Mermaid flowchart for CI/CD pipeline",
        "Create a Mermaid flowchart for user registration process",
    ],
    "erDiagram": [
        "Create a Mermaid erDiagram for users and orders",
        "Create a Mermaid erDiagram for blog with posts and comments",
    ],
    "stateDiagram": [
        "Create a Mermaid stateDiagram for order status",
        "Create a Mermaid stateDiagram for connection lifecycle",
    ],
}

# Quick test subset
QUICK_PROMPTS = {
    "sequenceDiagram": ["Create a Mermaid sequenceDiagram for user login"],
    "classDiagram": ["Create a Mermaid classDiagram for Repository pattern"],
    "flowchart": ["Create a Mermaid flowchart for error handling"],
    "erDiagram": ["Create a Mermaid erDiagram for users and orders"],
}


@dataclass
class TestResult:
    diagram_type: str
    prompt: str
    generated: bool
    extracted: bool
    valid_syntax: bool
    mermaid_code: Optional[str] = None
    error: Optional[str] = None
    raw_output: Optional[str] = None


def check_dependencies() -> bool:
    """Check if mermaid-cli is installed"""
    if shutil.which('mmdc') is None:
        print("❌ mermaid-cli not found!")
        print("   Install with: npm install -g @mermaid-js/mermaid-cli")
        return False
    return True


def extract_mermaid(text: str) -> Optional[str]:
    """Extract mermaid code from markdown code block"""
    # Try ```mermaid block first
    match = re.search(r'```mermaid\n(.*?)```', text, re.DOTALL)
    if match:
        return match.group(1).strip()

    # Try bare code block
    match = re.search(r'```\n(.*?)```', text, re.DOTALL)
    if match:
        code = match.group(1).strip()
        # Check if it looks like mermaid
        if any(kw in code for kw in ['sequenceDiagram', 'classDiagram', 'flowchart', 'erDiagram', 'stateDiagram', 'graph']):
            return code

    # Try to find raw mermaid without code block
    for kw in ['sequenceDiagram', 'classDiagram', 'flowchart', 'erDiagram', 'stateDiagram', 'graph']:
        if kw in text:
            # Find the start and try to extract
            start = text.find(kw)
            # Take until end marker or reasonable length
            end_markers = ['<|end|>', '\n\n\n', '```']
            end = len(text)
            for marker in end_markers:
                pos = text.find(marker, start)
                if pos > start:
                    end = min(end, pos)
            return text[start:end].strip()

    return None


def validate_mermaid(code: str) -> tuple[bool, str]:
    """Run mmdc to validate syntax"""
    with tempfile.NamedTemporaryFile(suffix='.mmd', delete=False, mode='w') as mmd_file:
        mmd_file.write(code)
        mmd_file.flush()

        with tempfile.NamedTemporaryFile(suffix='.svg', delete=False) as svg_file:
            result = subprocess.run(
                ['mmdc', '-i', mmd_file.name, '-o', svg_file.name, '-q'],
                capture_output=True,
                text=True,
                timeout=30
            )

            # Clean up
            Path(mmd_file.name).unlink(missing_ok=True)
            Path(svg_file.name).unlink(missing_ok=True)

            if result.returncode == 0:
                return True, ""
            else:
                return False, result.stderr or result.stdout


def generate_from_model(prompt: str, adapter_path: str, model: str) -> str:
    """Call model and get output"""
    result = subprocess.run([
        'python', '-m', 'mlx_lm', 'generate',
        '--model', model,
        '--adapter-path', adapter_path,
        '--max-tokens', '600',
        '--prompt', prompt
    ], capture_output=True, text=True, timeout=120)

    return result.stdout


def run_test(diagram_type: str, prompt: str, adapter_path: str, model: str) -> TestResult:
    """Run a single test"""
    result = TestResult(
        diagram_type=diagram_type,
        prompt=prompt,
        generated=False,
        extracted=False,
        valid_syntax=False
    )

    try:
        # Generate
        raw_output = generate_from_model(prompt, adapter_path, model)
        result.raw_output = raw_output
        result.generated = bool(raw_output and len(raw_output) > 50)

        if not result.generated:
            result.error = "No output generated"
            return result

        # Extract mermaid code
        mermaid_code = extract_mermaid(raw_output)
        result.mermaid_code = mermaid_code
        result.extracted = mermaid_code is not None

        if not result.extracted:
            result.error = "Could not extract Mermaid code"
            return result

        # Validate syntax
        is_valid, error = validate_mermaid(mermaid_code)
        result.valid_syntax = is_valid
        if not is_valid:
            result.error = f"Invalid syntax: {error[:200]}"

    except subprocess.TimeoutExpired:
        result.error = "Timeout"
    except Exception as e:
        result.error = str(e)

    return result


def print_result(result: TestResult, verbose: bool = False):
    """Print a single test result"""
    status = "✅" if result.valid_syntax else ("⚠️" if result.extracted else "❌")
    print(f"  {status} {result.diagram_type}: {result.prompt[:50]}...")

    if not result.valid_syntax and result.error:
        print(f"      Error: {result.error[:100]}")

    if verbose and result.mermaid_code:
        print(f"      Code preview: {result.mermaid_code[:100]}...")


def main():
    parser = argparse.ArgumentParser(description='Test Mermaid diagram generation')
    parser.add_argument('--adapter-path', default='adapters/design-analyst-v4',
                        help='Path to adapter weights')
    parser.add_argument('--model', default='microsoft/Phi-3-mini-4k-instruct',
                        help='Base model')
    parser.add_argument('--quick', action='store_true',
                        help='Run quick test (1 per diagram type)')
    parser.add_argument('--verbose', '-v', action='store_true',
                        help='Show detailed output')
    parser.add_argument('--save-results', type=str,
                        help='Save results to JSON file')
    parser.add_argument('--type', type=str, choices=list(TEST_PROMPTS.keys()),
                        help='Test only specific diagram type')
    args = parser.parse_args()

    # Check dependencies
    if not check_dependencies():
        sys.exit(1)

    print("=" * 60)
    print("Mermaid Generation Test Suite")
    print("=" * 60)
    print(f"Model: {args.model}")
    print(f"Adapter: {args.adapter_path}")
    print()

    # Select prompts
    prompts = QUICK_PROMPTS if args.quick else TEST_PROMPTS
    if args.type:
        prompts = {args.type: prompts[args.type]}

    # Run tests
    results = []
    total = sum(len(p) for p in prompts.values())
    current = 0

    for diagram_type, type_prompts in prompts.items():
        print(f"\n📊 Testing {diagram_type}:")

        for prompt in type_prompts:
            current += 1
            print(f"  [{current}/{total}] Running...", end='\r')

            result = run_test(prompt, prompt, args.adapter_path, args.model)
            results.append(result)
            print_result(result, args.verbose)

    # Summary
    print("\n" + "=" * 60)
    print("Summary")
    print("=" * 60)

    generated = sum(1 for r in results if r.generated)
    extracted = sum(1 for r in results if r.extracted)
    valid = sum(1 for r in results if r.valid_syntax)

    print(f"  Total tests:     {len(results)}")
    print(f"  Generated:       {generated}/{len(results)} ({100*generated//len(results)}%)")
    print(f"  Extracted:       {extracted}/{len(results)} ({100*extracted//len(results)}%)")
    print(f"  Valid syntax:    {valid}/{len(results)} ({100*valid//len(results)}%)")

    # Per-type breakdown
    print("\nBy diagram type:")
    for diagram_type in prompts.keys():
        type_results = [r for r in results if r.diagram_type == diagram_type]
        type_valid = sum(1 for r in type_results if r.valid_syntax)
        status = "✅" if type_valid == len(type_results) else "⚠️"
        print(f"  {status} {diagram_type}: {type_valid}/{len(type_results)}")

    # Save results
    if args.save_results:
        output = {
            "adapter_path": args.adapter_path,
            "model": args.model,
            "summary": {
                "total": len(results),
                "generated": generated,
                "extracted": extracted,
                "valid": valid
            },
            "results": [
                {
                    "diagram_type": r.diagram_type,
                    "prompt": r.prompt,
                    "generated": r.generated,
                    "extracted": r.extracted,
                    "valid_syntax": r.valid_syntax,
                    "mermaid_code": r.mermaid_code,
                    "error": r.error
                }
                for r in results
            ]
        }

        with open(args.save_results, 'w') as f:
            json.dump(output, f, indent=2)
        print(f"\nResults saved to {args.save_results}")

    # Exit code
    success_rate = valid / len(results) if results else 0
    sys.exit(0 if success_rate >= 0.8 else 1)


if __name__ == '__main__':
    main()