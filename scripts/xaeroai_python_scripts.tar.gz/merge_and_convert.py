#!/usr/bin/env python3
"""
Merge LoRA adapter into base model and convert to GGUF.

Usage:
  python scripts/merge_and_convert.py

Steps:
  1. Merge LoRA into Phi-3
  2. Convert to GGUF (F16)
  3. Quantize to Q4_K_M
"""

import argparse
import subprocess
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel


def merge_lora(base_model: str, lora_path: str, output_path: str):
    """Merge LoRA adapter into base model"""
    print(f"Loading base model: {base_model}")
    model = AutoModelForCausalLM.from_pretrained(
        base_model,
        torch_dtype=torch.float16,
        device_map="cpu",  # CPU for merging
        trust_remote_code=True,
    )

    print(f"Loading LoRA adapter: {lora_path}")
    model = PeftModel.from_pretrained(model, lora_path)

    print("Merging...")
    model = model.merge_and_unload()

    print(f"Saving merged model to: {output_path}")
    model.save_pretrained(output_path)

    # Save tokenizer too
    tokenizer = AutoTokenizer.from_pretrained(base_model, trust_remote_code=True)
    tokenizer.save_pretrained(output_path)

    print("Merge complete!")


def convert_to_gguf(model_path: str, output_path: str):
    """Convert HF model to GGUF format"""
    print(f"Converting to GGUF: {model_path} -> {output_path}")

    # Assumes llama.cpp is available
    convert_script = Path.home() / "llama.cpp" / "convert_hf_to_gguf.py"

    if not convert_script.exists():
        # Try brew location
        convert_script = Path("/opt/homebrew/bin/convert_hf_to_gguf.py")

    if not convert_script.exists():
        print("Warning: convert_hf_to_gguf.py not found")
        print("Run manually:")
        print(f"  python llama.cpp/convert_hf_to_gguf.py {model_path} --outfile {output_path}")
        return False

    result = subprocess.run([
        "python", str(convert_script),
        model_path,
        "--outfile", output_path,
        "--outtype", "f16"
    ], capture_output=True, text=True)

    if result.returncode != 0:
        print(f"Error: {result.stderr}")
        return False

    print("GGUF conversion complete!")
    return True


def quantize_gguf(input_path: str, output_path: str, quant_type: str = "q4_K_M"):
    """Quantize GGUF model"""
    print(f"Quantizing: {input_path} -> {output_path} ({quant_type})")

    # Find llama-quantize
    quantize_bin = Path.home() / "llama.cpp" / "build" / "bin" / "llama-quantize"

    if not quantize_bin.exists():
        quantize_bin = Path("/opt/homebrew/bin/llama-quantize")

    if not quantize_bin.exists():
        print("Warning: llama-quantize not found")
        print("Run manually:")
        print(f"  llama-quantize {input_path} {output_path} {quant_type}")
        return False

    result = subprocess.run([
        str(quantize_bin),
        input_path,
        output_path,
        quant_type
    ], capture_output=True, text=True)

    if result.returncode != 0:
        print(f"Error: {result.stderr}")
        return False

    print("Quantization complete!")
    return True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-model", default="microsoft/Phi-3-mini-4k-instruct")
    parser.add_argument("--lora-path", default="checkpoints/cyan-lens-v2")
    parser.add_argument("--merged-path", default="models/cyan-lens-v2-merged")
    parser.add_argument("--gguf-f16", default="models/cyan-lens-v2-f16.gguf")
    parser.add_argument("--gguf-q4", default="models/cyan-lens-v2-q4.gguf")
    parser.add_argument("--skip-merge", action="store_true")
    parser.add_argument("--skip-convert", action="store_true")
    args = parser.parse_args()

    # Ensure output dir exists
    Path("models").mkdir(exist_ok=True)

    # Step 1: Merge
    if not args.skip_merge:
        merge_lora(args.base_model, args.lora_path, args.merged_path)

    # Step 2: Convert to GGUF
    if not args.skip_convert:
        convert_to_gguf(args.merged_path, args.gguf_f16)

    # Step 3: Quantize
    quantize_gguf(args.gguf_f16, args.gguf_q4)

    print("\n=== Done! ===")
    print(f"Quantized model: {args.gguf_q4}")
    print("\nTo upload to HuggingFace:")
    print(f"  huggingface-cli upload blockxaero/cyan-lens {args.gguf_q4} cyan-lens-q4.gguf")


if __name__ == "__main__":
    main()