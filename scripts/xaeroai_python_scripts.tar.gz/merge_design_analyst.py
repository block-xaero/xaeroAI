#!/usr/bin/env python3
"""
Merge MLX LoRA adapter into base model and convert to GGUF.

Usage:
  python scripts/merge_design_analyst.py

Steps:
  1. Convert MLX adapter to PEFT format
  2. Merge into Phi-3
  3. Convert to GGUF (F16)
  4. Quantize to Q4_K_M
"""

import argparse
import subprocess
import json
import shutil
from pathlib import Path

import torch
from safetensors.torch import load_file, save_file
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel, LoraConfig, get_peft_model


def convert_mlx_to_peft(mlx_adapter_path: str, peft_output_path: str, num_layers: int = 16):
    """Convert MLX LoRA adapter to HuggingFace PEFT format"""
    print(f"Converting MLX adapter to PEFT format...")

    mlx_path = Path(mlx_adapter_path)
    peft_path = Path(peft_output_path)
    peft_path.mkdir(parents=True, exist_ok=True)

    # Load MLX adapter weights
    mlx_weights = load_file(mlx_path / "adapters.safetensors")

    # Map MLX keys to PEFT keys
    peft_weights = {}

    for key, value in mlx_weights.items():
        # MLX format: layers.{n}.self_attn.{q,k,v,o}_proj.lora_{a,b}.weight
        # PEFT format: base_model.model.model.layers.{n}.self_attn.{q,k,v,o}_proj.lora_{A,B}.weight

        new_key = f"base_model.model.model.{key}"
        # MLX uses lora_a/lora_b, PEFT uses lora_A/lora_B
        new_key = new_key.replace(".lora_a.", ".lora_A.")
        new_key = new_key.replace(".lora_b.", ".lora_B.")

        peft_weights[new_key] = value
        print(f"  {key} -> {new_key}")

    # Save PEFT weights
    save_file(peft_weights, peft_path / "adapter_model.safetensors")

    # Create adapter_config.json for PEFT
    config = {
        "alpha_pattern": {},
        "auto_mapping": None,
        "base_model_name_or_path": "microsoft/Phi-3-mini-4k-instruct",
        "bias": "none",
        "fan_in_fan_out": False,
        "inference_mode": True,
        "init_lora_weights": True,
        "layers_pattern": None,
        "layers_to_transform": None,
        "loftq_config": {},
        "lora_alpha": 16,
        "lora_dropout": 0.1,
        "megatron_config": None,
        "megatron_core": "megatron.core",
        "modules_to_save": None,
        "peft_type": "LORA",
        "r": 8,
        "rank_pattern": {},
        "revision": None,
        "target_modules": ["q_proj", "k_proj", "v_proj", "o_proj"],
        "task_type": "CAUSAL_LM",
        "use_dora": False,
        "use_rslora": False
    }

    with open(peft_path / "adapter_config.json", "w") as f:
        json.dump(config, f, indent=2)

    print(f"PEFT adapter saved to {peft_path}")
    return peft_path


def merge_lora(base_model: str, lora_path: str, output_path: str):
    """Merge LoRA adapter into base model"""
    print(f"Loading base model: {base_model}")
    model = AutoModelForCausalLM.from_pretrained(
        base_model,
        torch_dtype=torch.float16,
        device_map="cpu",  # CPU for merging
        trust_remote_code=True,
    )

    print(f"Loading LoRA adapter: {lora_path}")
    model = PeftModel.from_pretrained(model, lora_path)

    print("Merging...")
    model = model.merge_and_unload()

    print(f"Saving merged model to: {output_path}")
    model.save_pretrained(output_path, safe_serialization=True)

    # Save tokenizer too
    tokenizer = AutoTokenizer.from_pretrained(base_model, trust_remote_code=True)
    tokenizer.save_pretrained(output_path)

    print("Merge complete!")


def convert_to_gguf(model_path: str, output_path: str, convert_script: str = None):
    """Convert HF model to GGUF format"""
    print(f"Converting to GGUF: {model_path} -> {output_path}")

    # Find convert script
    if convert_script and Path(convert_script).exists():
        script = convert_script
    else:
        # Common locations
        candidates = [
            Path.home() / "llama.cpp" / "convert_hf_to_gguf.py",
            Path("/opt/homebrew/bin/convert_hf_to_gguf.py"),
            Path("convert_hf_to_gguf.py"),
            ]
        script = None
        for c in candidates:
            if c.exists():
                script = str(c)
                break

    if not script:
        print("Warning: convert_hf_to_gguf.py not found")
        print("Run manually:")
        print(f"  python convert_hf_to_gguf.py {model_path} --outfile {output_path} --outtype f16")
        return False

    print(f"Using convert script: {script}")
    result = subprocess.run([
        "python", script,
        model_path,
        "--outfile", output_path,
        "--outtype", "f16"
    ], capture_output=True, text=True)

    print(result.stdout)
    if result.returncode != 0:
        print(f"Error: {result.stderr}")
        return False

    print("GGUF conversion complete!")
    return True


def quantize_gguf(input_path: str, output_path: str, quant_type: str = "q4_K_M"):
    """Quantize GGUF model"""
    print(f"Quantizing: {input_path} -> {output_path} ({quant_type})")

    # Find llama-quantize
    candidates = [
        Path.home() / "llama.cpp" / "build" / "bin" / "llama-quantize",
        Path.home() / "llama.cpp" / "llama-quantize",
        Path("/opt/homebrew/bin/llama-quantize"),
        shutil.which("llama-quantize"),
        ]

    quantize_bin = None
    for c in candidates:
        if c and Path(c).exists():
            quantize_bin = str(c)
            break

    if not quantize_bin:
        print("Warning: llama-quantize not found")
        print("Run manually:")
        print(f"  llama-quantize {input_path} {output_path} {quant_type}")
        return False

    print(f"Using quantize binary: {quantize_bin}")
    result = subprocess.run([
        quantize_bin,
        input_path,
        output_path,
        quant_type
    ], capture_output=True, text=True)

    print(result.stdout)
    if result.returncode != 0:
        print(f"Error: {result.stderr}")
        return False

    print("Quantization complete!")
    return True


def main():
    parser = argparse.ArgumentParser(description="Merge MLX LoRA and convert to GGUF")
    parser.add_argument("--base-model", default="microsoft/Phi-3-mini-4k-instruct")
    parser.add_argument("--mlx-adapter", default="adapters/design-analyst-v4",
                        help="Path to MLX adapter directory")
    parser.add_argument("--peft-adapter", default="adapters/design-analyst-v4-peft",
                        help="Path to save converted PEFT adapter")
    parser.add_argument("--merged-path", default="models/design-analyst-v4-merged",
                        help="Path to save merged model")
    parser.add_argument("--gguf-f16", default="models/design-analyst-v4-f16.gguf")
    parser.add_argument("--gguf-q4", default="models/design-analyst-v4-q4.gguf")
    parser.add_argument("--convert-script", default=None,
                        help="Path to convert_hf_to_gguf.py")
    parser.add_argument("--skip-convert-adapter", action="store_true",
                        help="Skip MLX to PEFT conversion")
    parser.add_argument("--skip-merge", action="store_true")
    parser.add_argument("--skip-gguf", action="store_true")
    parser.add_argument("--skip-quantize", action="store_true")
    args = parser.parse_args()

    # Ensure output dir exists
    Path("models").mkdir(exist_ok=True)
    Path("adapters").mkdir(exist_ok=True)

    # Step 0: Convert MLX adapter to PEFT format
    if not args.skip_convert_adapter:
        convert_mlx_to_peft(args.mlx_adapter, args.peft_adapter)

    # Step 1: Merge LoRA into base model
    if not args.skip_merge:
        merge_lora(args.base_model, args.peft_adapter, args.merged_path)

    # Step 2: Convert to GGUF
    if not args.skip_gguf:
        convert_to_gguf(args.merged_path, args.gguf_f16, args.convert_script)

    # Step 3: Quantize
    if not args.skip_quantize:
        quantize_gguf(args.gguf_f16, args.gguf_q4)

    print("\n" + "=" * 60)
    print("Done!")
    print("=" * 60)
    print(f"\nQuantized model: {args.gguf_q4}")
    print("\nTest with llama.cpp:")
    print(f'  llama-cli -m {args.gguf_q4} -p "Create a Mermaid sequenceDiagram for user login" -n 300')
    print("\nOr create Ollama model:")
    print(f"  echo 'FROM ./{args.gguf_q4}' > Modelfile")
    print("  ollama create design-analyst -f Modelfile")
    print("  ollama run design-analyst")


if __name__ == "__main__":
    main()