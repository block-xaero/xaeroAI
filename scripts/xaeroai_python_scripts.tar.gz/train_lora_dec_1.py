#!/usr/bin/env python3
"""
Train LoRA adapter on Phi-3 for design pattern analysis.

Usage:
  python scripts/train_lora.py --data data/combined_train.jsonl

Requirements:
  pip install transformers peft datasets accelerate bitsandbytes
"""

import argparse
import json
from pathlib import Path

import torch
from datasets import Dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
    Trainer,
    DataCollatorForSeq2Seq,
)
from peft import LoraConfig, get_peft_model, TaskType


def load_training_data(path: str) -> list[dict]:
    """Load JSONL training data"""
    examples = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                examples.append(json.loads(line))
    return examples


def format_chat(messages: list[dict], tokenizer) -> str:
    """Format messages into Phi-3 chat template"""
    # Phi-3 chat format
    formatted = ""
    for msg in messages:
        role = msg["role"]
        content = msg["content"]

        if role == "system":
            formatted += f"<|system|>\n{content}<|end|>\n"
        elif role == "user":
            formatted += f"<|user|>\n{content}<|end|>\n"
        elif role == "assistant":
            formatted += f"<|assistant|>\n{content}<|end|>\n"

    return formatted


def prepare_dataset(examples: list[dict], tokenizer, max_length: int = 2048):
    """Prepare dataset for training"""

    def tokenize(example):
        text = format_chat(example["messages"], tokenizer)

        encodings = tokenizer(
            text,
            truncation=True,
            max_length=max_length,
            padding=False,
            return_tensors=None,
        )

        # For causal LM, labels = input_ids
        encodings["labels"] = encodings["input_ids"].copy()

        return encodings

    dataset = Dataset.from_list(examples)
    tokenized = dataset.map(tokenize, remove_columns=dataset.column_names)

    return tokenized


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=str, default="data/combined_train.jsonl")
    parser.add_argument("--base-model", type=str, default="microsoft/Phi-3-mini-4k-instruct")
    parser.add_argument("--output", type=str, default="checkpoints/cyan-lens-v2")
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--lr", type=float, default=2e-4)
    parser.add_argument("--lora-r", type=int, default=16)
    parser.add_argument("--lora-alpha", type=int, default=32)
    args = parser.parse_args()

    print(f"=== Cyan Lens Training ===")
    print(f"Data: {args.data}")
    print(f"Base model: {args.base_model}")
    print(f"Output: {args.output}")

    # Load data
    examples = load_training_data(args.data)
    print(f"Loaded {len(examples)} training examples")

    # Load tokenizer
    print("Loading tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(args.base_model, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # Prepare dataset
    print("Preparing dataset...")
    dataset = prepare_dataset(examples, tokenizer)
    print(f"Dataset ready: {len(dataset)} examples")

    # Load model
    print("Loading model...")
    model = AutoModelForCausalLM.from_pretrained(
        args.base_model,
        torch_dtype=torch.bfloat16,
        device_map="auto",
        trust_remote_code=True,
    )

    # Configure LoRA
    print("Configuring LoRA...")
    lora_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=args.lora_r,
        lora_alpha=args.lora_alpha,
        lora_dropout=0.05,
        target_modules=["qkv_proj", "o_proj", "gate_up_proj", "down_proj"],
        bias="none",
    )

    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()

    # Training arguments
    training_args = TrainingArguments(
        output_dir=args.output,
        num_train_epochs=args.epochs,
        per_device_train_batch_size=args.batch_size,
        gradient_accumulation_steps=4,
        learning_rate=args.lr,
        weight_decay=0.01,
        warmup_ratio=0.03,
        lr_scheduler_type="cosine",
        logging_steps=10,
        save_strategy="epoch",
        save_total_limit=2,
        bf16=True,
        gradient_checkpointing=True,
        optim="adamw_torch",
        report_to="none",
    )

    # Data collator
    data_collator = DataCollatorForSeq2Seq(
        tokenizer=tokenizer,
        padding=True,
        return_tensors="pt",
    )

    # Train
    print("Starting training...")
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=dataset,
        data_collator=data_collator,
    )

    trainer.train()

    # Save
    print(f"Saving to {args.output}...")
    trainer.save_model(args.output)
    tokenizer.save_pretrained(args.output)

    print("Done!")


if __name__ == "__main__":
    main()