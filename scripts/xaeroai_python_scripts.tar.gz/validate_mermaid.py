#!/usr/bin/env python3
"""
Validate Mermaid syntax in training data.
Filters out examples with broken Mermaid.

Requires: npm install -g @mermaid-js/mermaid-cli
"""

import json
import subprocess
import tempfile
import re
from pathlib import Path

INPUT_FILE = Path("data/patterns/mermaid_examples.jsonl")
OUTPUT_FILE = Path("data/patterns/mermaid_validated.jsonl")


def extract_mermaid(text: str) -> list[str]:
    """Extract all mermaid code blocks from text."""
    pattern = r'```mermaid\s*(.*?)```'
    matches = re.findall(pattern, text, re.DOTALL)
    return [m.strip() for m in matches]


def validate_mermaid(code: str) -> tuple[bool, str]:
    """Validate mermaid syntax using mmdc CLI."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.mmd', delete=False) as f:
        f.write(code)
        input_path = f.name

    output_path = input_path.replace('.mmd', '.svg')

    try:
        result = subprocess.run(
            ['mmdc', '-i', input_path, '-o', output_path],
            capture_output=True,
            text=True,
            timeout=10
        )

        # Clean up
        Path(input_path).unlink(missing_ok=True)
        Path(output_path).unlink(missing_ok=True)

        if result.returncode == 0:
            return True, ""
        else:
            return False, result.stderr or result.stdout

    except subprocess.TimeoutExpired:
        return False, "Timeout"
    except FileNotFoundError:
        print("ERROR: mmdc not found. Install with: npm install -g @mermaid-js/mermaid-cli")
        exit(1)
    except Exception as e:
        return False, str(e)


def main():
    if not INPUT_FILE.exists():
        print(f"Input file not found: {INPUT_FILE}")
        return

    examples = []
    with open(INPUT_FILE) as f:
        for line in f:
            if line.strip():
                examples.append(json.loads(line))

    print(f"Loaded {len(examples)} examples")
    print("Validating Mermaid syntax...\n")

    valid_examples = []
    invalid_count = 0
    no_mermaid_count = 0

    for i, ex in enumerate(examples):
        # Get assistant response
        assistant_msg = None
        for msg in ex.get("messages", []):
            if msg.get("role") == "assistant":
                assistant_msg = msg.get("content", "")
                break

        if not assistant_msg:
            continue

        # Extract mermaid blocks
        mermaid_blocks = extract_mermaid(assistant_msg)

        if not mermaid_blocks:
            # No mermaid in this example - keep it (might be health analysis)
            valid_examples.append(ex)
            no_mermaid_count += 1
            continue

        # Validate each mermaid block
        all_valid = True
        for block in mermaid_blocks:
            is_valid, error = validate_mermaid(block)
            if not is_valid:
                all_valid = False
                print(f"[{i+1}] INVALID: {error[:100]}...")
                break

        if all_valid:
            valid_examples.append(ex)
            print(f"[{i+1}] ✓", end=" ", flush=True)
            if (i + 1) % 20 == 0:
                print()
        else:
            invalid_count += 1

    print(f"\n\nResults:")
    print(f"  Total examples: {len(examples)}")
    print(f"  Valid mermaid: {len(valid_examples) - no_mermaid_count}")
    print(f"  No mermaid (kept): {no_mermaid_count}")
    print(f"  Invalid (removed): {invalid_count}")
    print(f"  Final count: {len(valid_examples)}")

    # Save validated examples
    with open(OUTPUT_FILE, "w") as f:
        for ex in valid_examples:
            f.write(json.dumps(ex) + "\n")

    print(f"\nSaved to {OUTPUT_FILE}")


if __name__ == "__main__":
    main()