#!/usr/bin/env python3
"""
Retry failed Mermaid categories and append to existing file.
"""

import json
import time
from pathlib import Path
from anthropic import Anthropic

OUTPUT_FILE = Path("data/patterns/mermaid_examples.jsonl")
client = Anthropic()

SYSTEM_PROMPT = """You are a software design analyst for Cyan, a design-first collaboration tool. You have deep expertise in:
- Design patterns (GoF, enterprise, microservices, Rust idioms)
- Software architecture (clean architecture, DDD, CQRS, event sourcing)
- UML and diagram generation using Mermaid syntax
- Project health analysis from integration data

When asked for diagrams, output valid Mermaid syntax in a code block. Be specific, actionable, and concise."""

# Only the failed categories - with fixed prompts (no curly braces in examples)
FAILED_CATEGORIES = [
    {
        "category": "class_enterprise",
        "count": 25,
        "prompt": """Generate 25 training examples for CLASS DIAGRAMS of enterprise/DDD patterns.

Patterns: Repository, Unit of Work, Service Layer, Domain Model, Data Mapper, Active Record, Table Module, Aggregate, Entity, Value Object, Domain Event, Specification, CQRS read/write models.

Each should have Mermaid classDiagram with proper relationships.

Output as JSON array. Each object must have "instruction" and "output" keys.
Keep each example concise to avoid truncation."""
    },
    {
        "category": "class_rust",
        "count": 20,
        "prompt": """Generate 20 training examples for CLASS DIAGRAMS showing Rust-idiomatic patterns.

Topics: Trait objects, Newtype pattern, Builder with typestate, Error handling with Result, Actor model, Channel-based observer, Smart pointers (Box, Rc, Arc), Interior mutability (RefCell, Mutex).

Show traits as interfaces, impl as inheritance. Include short Rust code snippets.

Output as JSON array. Each object must have "instruction" and "output" keys.
Keep examples concise."""
    },
    {
        "category": "er_domains",
        "count": 25,
        "prompt": """Generate 25 training examples for ER DIAGRAMS of various domains.

Domains: E-commerce (orders, products, users), Blog/CMS, Task management, Chat/messaging, Calendar/booking, Inventory, HR/employees, Social network, Event sourcing tables, Multi-tenant SaaS.

Use Mermaid erDiagram with proper relationships, column types, PK/FK.
Example relationship syntax: USER one-to-many ORDER, PRODUCT many-to-many CATEGORY

Output as JSON array. Each object must have "instruction" and "output" keys.
Keep examples concise."""
    },
    {
        "category": "architecture",
        "count": 30,
        "prompt": """Generate 30 training examples for ARCHITECTURE/COMPONENT DIAGRAMS using Mermaid flowchart with subgraphs.

Topics: Microservices layout, Clean architecture layers, Hexagonal architecture, P2P network topology, Event-driven architecture, API gateway pattern, BFF pattern, Sidecar pattern, Service mesh, Data pipeline.

Use flowchart with subgraphs for logical grouping, styled nodes.

Output as JSON array. Each object must have "instruction" and "output" keys.
Keep examples concise."""
    },
    {
        "category": "health_with_diagram",
        "count": 20,
        "prompt": """Generate 20 training examples where user provides project health context AND asks for a diagram.

User message format:
<context>
Ticket info, Slack mentions, PRs, etc.
</context>
Question asking for analysis AND a diagram

Response should:
1. Analyze the health issue (use emoji red/yellow/green with evidence)
2. Provide a relevant Mermaid diagram (sequence, flowchart, or class)
3. Explain how the diagram addresses the issue

Output as JSON array. Each object must have "instruction" and "output" keys."""
    },
]


def generate_examples(category: dict) -> list:
    """Generate examples for a category using Claude."""
    prompt = f"""Generate exactly {category["count"]} training examples as a JSON array.

{category["prompt"]}

IMPORTANT: 
- Output ONLY a valid JSON array, no other text
- Start with [ and end with ]
- Each object must have "instruction" and "output" keys
- Keep each example under 1000 characters to avoid truncation
- Escape special characters properly in JSON strings"""

    try:
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=16000,
            messages=[{
                "role": "user",
                "content": prompt
            }]
        )

        text = response.content[0].text.strip()

        # Try to find JSON array
        start = text.find('[')
        end = text.rfind(']') + 1

        if start >= 0 and end > start:
            json_str = text[start:end]
            try:
                examples = json.loads(json_str)
                return examples
            except json.JSONDecodeError as e:
                print(f"  JSON parse error: {e}")
                # Try fixing common issues
                json_str = json_str.replace(",]", "]").replace(",\n]", "\n]")
                # Try to salvage partial results
                try:
                    examples = json.loads(json_str)
                    return examples
                except:
                    # Try to extract individual objects
                    print(f"  Attempting to salvage partial results...")
                    salvaged = salvage_json(text)
                    if salvaged:
                        print(f"  Salvaged {len(salvaged)} examples")
                        return salvaged

                    with open(f"debug_{category['category']}.txt", "w") as f:
                        f.write(text)
                    return []
        else:
            print(f"  Warning: No JSON array found")
            return []

    except Exception as e:
        print(f"  Error: {e}")
        return []


def salvage_json(text: str) -> list:
    """Try to extract valid JSON objects from broken response."""
    import re

    results = []
    # Find all potential JSON objects
    pattern = r'\{\s*"instruction"\s*:\s*"[^"]*"\s*,\s*"output"\s*:\s*"[^"]*"\s*\}'

    # Simpler approach: find instruction/output pairs
    parts = text.split('{"instruction"')
    for part in parts[1:]:  # Skip first empty part
        try:
            # Reconstruct and try to parse
            obj_str = '{"instruction"' + part
            # Find the closing brace
            brace_count = 0
            end_idx = 0
            for i, c in enumerate(obj_str):
                if c == '{':
                    brace_count += 1
                elif c == '}':
                    brace_count -= 1
                    if brace_count == 0:
                        end_idx = i + 1
                        break

            if end_idx > 0:
                obj_str = obj_str[:end_idx]
                obj = json.loads(obj_str)
                if "instruction" in obj and "output" in obj:
                    results.append(obj)
        except:
            continue

    return results


def convert_to_messages(example: dict) -> dict:
    """Convert to MLX messages format."""
    return {
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": example["instruction"]},
            {"role": "assistant", "content": example["output"]}
        ]
    }


def main():
    # Load existing examples
    existing = []
    if OUTPUT_FILE.exists():
        with open(OUTPUT_FILE) as f:
            for line in f:
                if line.strip():
                    existing.append(json.loads(line))
        print(f"Existing examples: {len(existing)}")

    new_examples = []

    print(f"\nRetrying {len(FAILED_CATEGORIES)} failed categories...\n")

    for i, category in enumerate(FAILED_CATEGORIES):
        print(f"[{i+1}/{len(FAILED_CATEGORIES)}] {category['category']} (target: {category['count']})")

        examples = generate_examples(category)
        print(f"    Generated: {len(examples)}")

        new_examples.extend(examples)

        # Rate limiting
        if i < len(FAILED_CATEGORIES) - 1:
            print(f"    Waiting 60s for rate limit...")
            time.sleep(60)

    print(f"\nNew examples generated: {len(new_examples)}")

    # Convert to messages format
    formatted_new = [convert_to_messages(ex) for ex in new_examples if ex.get("instruction") and ex.get("output")]
    print(f"Valid new examples: {len(formatted_new)}")

    # Combine with existing
    all_examples = existing + formatted_new
    print(f"Total examples: {len(all_examples)}")

    # Save
    with open(OUTPUT_FILE, "w") as f:
        for ex in all_examples:
            f.write(json.dumps(ex) + "\n")

    print(f"Saved to {OUTPUT_FILE}")

    # Stats
    print("\nDiagram types in output:")
    content = str(all_examples)
    for dtype in ["classDiagram", "sequenceDiagram", "flowchart", "stateDiagram", "erDiagram"]:
        count = content.count(dtype)
        print(f"  {dtype}: {count}")


if __name__ == "__main__":
    main()