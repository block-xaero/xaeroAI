from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

model_id = "microsoft/Phi-3-mini-4k-instruct"

print("Loading tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(model_id)

print("Loading model (this may take a few minutes first time)...")
model = AutoModelForCausalLM.from_pretrained(
    model_id,
    torch_dtype=torch.float16,
    device_map="auto"
)

print(f"Model loaded on: {model.device}")
print(f"Memory used: {model.get_memory_footprint() / 1e9:.2f} GB")

# Test with a simple design analyst prompt
messages = [
    {"role": "system", "content": "You are a software design analyst. Be concise."},
    {"role": "user", "content": "A ticket has 47 Slack mentions but 0 PRs after 45 days. What's wrong?"}
]

inputs = tokenizer.apply_chat_template(messages, return_tensors="pt", return_dict=True).to(model.device)

print("\nGenerating response...")
outputs = model.generate(
    **inputs,
    max_new_tokens=100,
    do_sample=False
)

response = tokenizer.decode(outputs[0], skip_special_tokens=True)
print("\n" + "="*50)
print(response)
print("="*50)
print("\n✅ Phi-3 working!")