#!/usr/bin/env python3
"""Retry failed patterns and append better examples to existing data."""

import json
import os
import time
from pathlib import Path

try:
    import anthropic
    HAS_ANTHROPIC = True
except ImportError:
    HAS_ANTHROPIC = False

# Patterns that had JSON parse errors (got template fallbacks)
FAILED_PATTERNS = [
    "Coercion Arguments",
    "Concatenation with format!",
    "Default Trait",
    "Deref Polymorphism",
    "Finalisation in Destructors",
    "mem::replace",
    "On-Stack Dynamic Dispatch",
    "Option Iterator",
    "Pass Variables to Closure",
    "Private Field Extension",
    "Temporary Mutability",
    "Newtype Pattern",
    "RAII Guards",
    "Strategy Pattern",
    "Builder Pattern",
    "Fold Pattern",
    "Compose Structs",
    "Error Wrapping",
    "Functional Options",
    "Interface Segregation",
    "Context Propagation",
    "Table-Driven Tests",
    "Fan-Out Fan-In",
    "Channel Pipeline",
    "Struct Embedding",
    "Constructor",
    "Dependency Injection",
    "Service Locator",
    "Inversion of Control",
]


def generate_examples_for_pattern(client, pattern: dict) -> list:
    """Generate examples using Claude API with stricter JSON instructions."""

    prompt = f"""Generate 3 training examples for the "{pattern['name']}" software pattern.

Pattern description: {pattern.get('description', 'A software design pattern')}
Category: {pattern.get('category', 'general')}
Source: {pattern.get('source', 'unknown')}

Each example should be a realistic question a developer might ask, paired with a helpful answer.
Focus on practical Rust implementations where applicable.

CRITICAL: Return ONLY valid JSON array. No markdown, no code blocks, no explanation.
Do not use unescaped quotes inside strings. Use single quotes or escape with backslash.

Format exactly like this (no other text):
[
  {{"question": "How do I implement X?", "answer": "Here is how to implement X..."}},
  {{"question": "When should I use Y?", "answer": "Use Y when..."}}
]"""

    try:
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=2000,
            messages=[{"role": "user", "content": prompt}]
        )

        content = response.content[0].text.strip()

        # Clean up common issues
        if content.startswith("```"):
            lines = content.split("\n")
            content = "\n".join(lines[1:-1] if lines[-1] == "```" else lines[1:])

        # Try to extract JSON array
        start = content.find("[")
        end = content.rfind("]") + 1
        if start >= 0 and end > start:
            content = content[start:end]

        examples = json.loads(content)

        result = []
        for ex in examples:
            if "question" in ex and "answer" in ex:
                result.append({
                    "instruction": ex["question"],
                    "input": "",
                    "output": ex["answer"],
                    "pattern": pattern["name"],
                    "category": pattern.get("category", "unknown"),
                    "source": pattern.get("source", "unknown"),
                    "generation": "claude-retry"
                })

        return result if result else generate_template_examples(pattern)

    except json.JSONDecodeError as e:
        print(f"    JSON parse error (retry): {e}")
        return generate_template_examples(pattern)
    except Exception as e:
        print(f"    API error: {e}")
        return generate_template_examples(pattern)


def generate_template_examples(pattern: dict) -> list:
    """Generate template-based examples."""
    name = pattern["name"]
    category = pattern.get("category", "general")

    templates = [
        {
            "instruction": f"What is the {name} pattern and when should I use it in Rust?",
            "output": f"The {name} pattern is used in {category} contexts. In Rust, you would implement it using traits and structs to achieve clean separation of concerns. Use it when you need to decouple components or improve code organization."
        },
        {
            "instruction": f"Can you show me a simple Rust implementation of {name}?",
            "output": f"Here's a basic {name} implementation in Rust:\n\n```rust\n// Define the core trait\npub trait {name.replace(' ', '')} {{\n    fn execute(&self);\n}}\n\n// Implement for concrete type\nstruct Concrete;\nimpl {name.replace(' ', '')} for Concrete {{\n    fn execute(&self) {{\n        // Implementation here\n    }}\n}}\n```\n\nThis pattern helps with {category} by providing a clean abstraction."
        },
        {
            "instruction": f"What are the trade-offs of using {name} in a Rust project?",
            "output": f"The {name} pattern has several trade-offs in Rust:\n\nPros:\n- Improves code organization and separation of concerns\n- Makes testing easier through abstraction\n- Leverages Rust's trait system effectively\n\nCons:\n- Adds some indirection and complexity\n- May require more boilerplate code\n- Can be overkill for simple use cases\n\nConsider your specific needs in the {category} domain before applying it."
        },
        {
            "instruction": f"How does {name} compare to similar patterns?",
            "output": f"The {name} pattern in the {category} category differs from related patterns in its specific focus and implementation approach. In Rust, it leverages the type system and ownership model to provide compile-time guarantees that other languages achieve through runtime checks."
        },
    ]

    return [
        {
            "instruction": t["instruction"],
            "input": "",
            "output": t["output"],
            "pattern": name,
            "category": category,
            "source": pattern.get("source", "unknown"),
            "generation": "template-retry"
        }
        for t in templates
    ]


def main():
    data_dir = Path("data/patterns")

    # Load raw patterns to get full info
    raw_patterns_file = data_dir / "raw_patterns.json"
    if not raw_patterns_file.exists():
        print(f"Error: {raw_patterns_file} not found")
        return

    with open(raw_patterns_file) as f:
        all_patterns = json.load(f)

    # Filter to only failed patterns
    patterns_to_retry = [p for p in all_patterns if p["name"] in FAILED_PATTERNS]
    print(f"Found {len(patterns_to_retry)} patterns to retry")

    # Load existing examples
    existing_file = data_dir / "generated_examples.jsonl"
    existing_examples = []
    if existing_file.exists():
        with open(existing_file) as f:
            for line in f:
                if line.strip():
                    existing_examples.append(json.loads(line))
        print(f"Loaded {len(existing_examples)} existing examples")

    # Initialize client
    client = None
    if HAS_ANTHROPIC and os.environ.get("ANTHROPIC_API_KEY"):
        client = anthropic.Anthropic()
        print("Using Claude API for retry generation")
    else:
        print("No API - using templates only")

    # Generate new examples for failed patterns
    new_examples = []
    for i, pattern in enumerate(patterns_to_retry):
        print(f"[{i+1}/{len(patterns_to_retry)}] Retrying: {pattern['name']}")

        if client:
            examples = generate_examples_for_pattern(client, pattern)
            time.sleep(0.5)
        else:
            examples = generate_template_examples(pattern)

        new_examples.extend(examples)
        print(f"    Generated {len(examples)} examples")

    # Append new examples to file
    with open(existing_file, "a") as f:
        for ex in new_examples:
            f.write(json.dumps(ex) + "\n")

    total = len(existing_examples) + len(new_examples)
    print(f"\nDone! Added {len(new_examples)} new examples")
    print(f"Total examples now: {total}")


if __name__ == "__main__":
    main()